
(() => {
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const SVG = "http://www.w3.org/2000/svg";
const el = (n, a = {}) => { const e = document.createElementNS(SVG, n); for (const k in a) e.setAttribute(k, a[k]); return e; };
const ms = (us) => (us / 1000).toFixed(us >= 1000 ? 2 : 3);
const mib = (b) => (b / 1024 / 1024).toFixed(b > 1024 * 1024 ? 0 : 1);

// Amber marks low concurrency; red is reserved for full-device idle gaps.
// Candidates and selection use the neutral scale; core type is a tint.
const C = { accent: "#fd5644", accentDim: "#7e3129", warn: "#b98a45", candidate: "#a8a8a8", sel: "#f0f0f0",
            block: "#565656", AIC: "#8e8e8e", AIV: "#606060",
            plain: "#3a3a3a", idle: "#232323", grid: "#262626", axis: "#999999", label: "#aaaaaa" };

let D, R, me = null, lens = "wait", laneAll = true, laneView = "core", laneColor = "none", laneRange = null, taskLayer = "recommended";
let recommendedFocus = null, candidateFilter = "recommended", pathVisible = false, settingsOpen = false;
let qkInline = null, qkReturnView = null, openQkInlinePass = () => {};
let inlineEvolution=false,inlineReturnRange=null,inlineZoomFrom=null;const inlineEvolutionState={pass:'memory',iter:0,object:'q'};
let laneExpanded = false, laneComposition = false, laneRowCenters = [];
let laneZoomRaf = 0;
let singleChains = [], singleSelected = null, singlePanelOpen = false, singlePreviousRange = null, singlePreviousScroll = 0;
const ovl = { ribbon: true, bands: true, marks: true };
function laneLeft() { return qkInline && laneView === "core" ? 188 : 76; }

const LENS = {
  wait: { label: "关键路径上的等待", hint: "单块任务串在关键路径上，零计算，纯等 rank 间数据或上游同步 —— 这段时间加核也不会变快。" },
  tail: { label: "尾块浪费", hint: "（最慢块 − 平均块）× 块数，是所有块同时启动时的核时损失上界；离散大而 p90 贴近中位 = 个别块掉队。" },
  setup: { label: "启动开销", hint: "launch / setup 成本占比高的提交，通常是块多、单块短的小 kernel，融合可能比调优单块更有效。" },
  waves: { label: "并行波次", hint: "块数超过可用物理核数就要分多轮派发；只有落在关键路径上的波次才影响端到端。" },
};

function candidatesFor(id) {
  const byTask = (taskId) => R.launches.find((l) => l.taskId === String(taskId));
  if (id === "wait") {
    const byId = new Map(R.launches.map((l) => [l.id, l]));
    return R.criticalPath.filter((p) => p.blockNum === 1 && p.spanUs > 0)
      .map((p) => (p.ids?.length ? byId.get(p.ids[0]) : byTask(p.taskId))).filter(Boolean)
      .sort((a, b) => b.spanUs - a.spanUs).slice(0, 5);
  }
  if (id === "tail") return R.launches.filter((l) => l.tailWasteUs > 0).slice().sort((a, b) => b.tailWasteUs - a.tailWasteUs).slice(0, 5);
  if (id === "setup") return R.launches.slice().sort((a, b) => (b.setupUs / (b.setupUs + b.computeUs || 1)) - (a.setupUs / (a.setupUs + a.computeUs || 1))).slice(0, 5);
  if (id === "waves") return R.launches.slice().sort((a, b) => b.waves - a.waves || b.spanUs - a.spanUs).slice(0, 5);
  return [];
}
const lensMetric = (x) => lens === "tail" ? `${ms(x.tailWasteUs)} ms 尾块`
  : lens === "setup" ? `${(x.setupUs / (x.setupUs + x.computeUs || 1) * 100).toFixed(0)}% setup`
  : lens === "waves" ? `${x.waves} 波` : `${ms(x.spanUs)} ms 跨度`;

// ---------- run summary + lenses ----------
function header() {
  $("window-readout").textContent = ms(R.kpi.windowUs) + " ms";
  const k = R.kpi;
  const cs = concStats();
  const pct = (value) => (value * 100).toFixed(1) + "%";
  const stats = [
    { label: "执行窗口", value: ms(k.windowUs), unit: "ms", sub: k.totalTasks + " 次提交 · " + k.totalCores + " 个核",
      help: "当前 rank 的设备 trace 窗口，与泳道完整时间轴一致；不是关键路径任务跨度的链式相加值。" },
    { label: "关键路径单块时长", value: pct(k.singleBlockOnPathShare), sub: ms(k.singleBlockOnPathUs) + " / 路径 " + ms(k.criticalPathUs) + " ms",
      help: "关键路径上 block_num=1 的 Task 实测区间合并后 ÷ 路径时间跨度。单块表示并行度为 1，不等同于已确认的等待。" },
    { label: "平均计算利用率", value: pct(k.occupancy),
      sub: "AIC " + pct(k.byType.AIC.computeShare) + " · AIV " + pct(k.byType.AIV.computeShare),
      help: "累计计算核时 ÷（执行窗口 × 可用核数）；不包含 Setup 占核时间。" },
    { label: "低并行时段占比", value: pct(cs.lowUs / Math.max(1, k.windowUs)), sub: "≤2 核运行 · 全机空闲 " + ms(cs.gapUs) + " ms",
      help: "运行核数不超过 2 的时段总时长 ÷ 设备窗口，包含全机 0 核运行的空闲时段。" },
    { label: "启动 / 计算核时", value: pct(k.setupUs / Math.max(1, k.computeUs)), sub: "Setup " + ms(k.setupUs) + " ms 核时",
      help: "累计 Setup 核时 ÷ 累计计算核时；这是两个累计核时的比值，不是启动时间占执行窗口的比例。" },
  ];
  $("perf-overview").innerHTML = stats.map((stat) => '<div class="perf-stat" data-tooltip="' + esc(stat.sub + '\n' + stat.help) + '"><dt>' + esc(stat.label)
    + '</dt><dd>' + esc(stat.value) + (stat.unit ? '<span>' + esc(stat.unit) + '</span>' : '')
    + '</dd><small>' + esc(stat.sub) + '</small></div>').join("");
  $("sum").innerHTML = `窗口 <b>${ms(k.windowUs)} ms</b> · ${k.totalTasks} 次提交，关键路径上 ${k.criticalPathTasks} 个`
    + ` · ${k.totalCores} 核占用 <b>${(k.occupancy * 100).toFixed(0)}%</b> · 声明搬运 <b>${mib(k.bytesTotal)} MiB</b>`;
}

// ---------- critical path ----------
function criticalPath() {
  const svg = $("cp"); svg.textContent = "";
  const total = R.criticalPath.reduce((a, p) => a + (p.pathContributionUs ?? p.spanUs), 0) || 1;
  const W = Math.max(600, Math.floor($("lane-wrap").clientWidth || 600));
  const H = 32, GAP = 3, TOP = 4, BAR = 22;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("width", W); svg.setAttribute("height", H);
  const LEFT=laneLeft(),RIGHT=12;
  let x = LEFT;
  R.criticalPath.forEach((p) => {
    const contributionUs = p.pathContributionUs ?? p.spanUs;
    const w = Math.max(1.2, (contributionUs / total) * (W - LEFT - RIGHT - (R.criticalPath.length - 1) * GAP));
    const isWait = p.blockNum === 1 || !p.onCore;
    const isSel = me && p.ids.includes(me);
    const g = el("g", { class: "cp-seg", "data-t": p.taskId, role:"button", tabindex:0, "aria-label":p.name, style: "cursor:pointer" });
    g.append(el("rect", { x, y: TOP, width: w, height: BAR,
      fill: isSel ? C.sel : isWait ? C.accent : C.AIC, opacity: isWait || isSel ? 1 : .55 }));
    if(w>38){
      const color=isSel||isWait?'#111111':'#ffffff';
      const duration=`${ms(p.spanUs)} ms`,durationWidth=duration.length*6+10;
      const showDuration=w>110;
      const nameWidth=w-12-(showDuration?durationWidth+8:0);
      const count=Math.max(1,Math.floor(nameWidth/6.6));
      const name=el('text',{x:x+5,y:TOP+14,fill:color,'font-family':'var(--mono)',style:'font-size:11px','pointer-events':'none'});
      name.textContent=p.name.length>count?p.name.slice(0,Math.max(1,count-1))+'…':p.name;g.append(name);
      if(showDuration){
        const time=el('text',{x:x+w-5,y:TOP+14,'text-anchor':'end',fill:color,'font-family':'var(--mono)',style:'font-size:10px','pointer-events':'none'});
        time.textContent=duration;g.append(time);
      }
    }
    const ttl = el("desc", {});
    ttl.textContent = `${p.name}\n实测跨度 ${ms(p.spanUs)} ms · 路径新增时间 ${ms(contributionUs)} ms · 算 ${ms(p.computeUs)} ms · ${p.blockNum ?? "—"} 块`;
    g.append(ttl); svg.append(g);
    x += w + GAP;
  });
  svg.onclick = (e) => { const tag=e.target.closest?.("[data-result-tag]");if(tag){focusRecommendation(tag.dataset.resultTag);return;} const g = e.target.closest && e.target.closest(".cp-seg"); if (g) window.CriticalPathIntegration.choose(g.getAttribute("data-t")); };
  svg.onkeydown=e=>{if(["Enter"," "].includes(e.key)){const g=e.target.closest?.(".cp-seg");if(g){e.preventDefault();window.CriticalPathIntegration.choose(g.dataset.t);}}};
  svg.onpointerover=e=>{const g=e.target.closest?.('.cp-seg');if(g)drawLaneRelations((laneRelationIndex?.byTask.get(g.dataset.t)||[])[0]?.element);};
  svg.onpointerleave=()=>drawLaneRelations();
  const waitN = R.criticalPath.filter((p) => p.blockNum === 1 && p.spanUs > 0).length;
  $("cp-sub").innerHTML = `设备时间跨度 <b>${ms(R.kpi.criticalPathUs)} ms</b> / ${R.criticalPath.length} 个任务，其中 ${waitN} 个是单块任务`;
}

// ---------- device lane ----------
// Two layers. The base is 4038 blocks drawn as flat, quiet texture — it answers
// "what is the shape of this run" and nothing else. Everything that asks for
// attention is computed structure drawn on top of it.
function concStats() {
  if (R._conc) return R._conc;
  const ev = [];
  for (const l of R.launches) for (const b of (l.blocks.items || [])) { ev.push([b.startUs, 1]); ev.push([b.endUs, -1]); }
  ev.sort((a, b) => a[0] - b[0] || a[1] - b[1]);   // ends before starts at a shared instant
  const segs = []; let n = 0, t = ev.length ? ev[0][0] : 0;
  for (let i = 0; i < ev.length;) {
    const tt = ev[i][0];
    if (tt > t) { segs.push([t, tt, n]); t = tt; }
    while (i < ev.length && ev[i][0] === tt) { n += ev[i][1]; i++; }
  }
  const win = R.kpi.windowUs, minRun = Math.max(8, win / 500);
  const merge = (pred, min) => {
    const out = []; let cur = null;
    for (const s of segs) {
      if (pred(s[2])) {
        if (cur && Math.abs(cur.t1 - s[0]) < 1e-9) cur.t1 = s[1];
        else { cur = { t0: s[0], t1: s[1] }; out.push(cur); }
      } else cur = null;
    }
    return out.filter((r) => r.t1 - r.t0 >= min).sort((a, b) => (b.t1 - b.t0) - (a.t1 - a.t0));
  };
  const span = (pred) => segs.filter((s) => pred(s[2])).reduce((a, s) => a + (s[1] - s[0]), 0);
  R._conc = {
    segs,
    gaps: merge((c) => c === 0, minRun),                 // nothing running anywhere
    serial: merge((c) => c >= 1 && c <= 2, minRun * 2),  // one or two cores carrying the device
    gapUs: span((c) => c === 0), lowUs: span((c) => c <= 2),
    peak: segs.length ? Math.max(...segs.map((s) => s[2])) : 0,
  };
  return R._conc;
}

// Time-range landmarks. The first is fixed, the second follows the active lens,
// so the overlay always points at whatever the page is currently about.
function landmarks() {
  const out = [];
  const cs = concStats();
  const longest = R.launches.reduce((a, b) => (b.spanUs > a.spanUs ? b : a));
  const top = candidatesFor(lens)[0];
  // the lens pick and the longest task are often the same launch — say so once
  const sameAsLongest = top && top.id === longest.id && lens !== "tail";
  out.push({
    label: sameAsLongest ? `最长 Task，也是${LENS[lens].label} Top1 · ${longest.leaf}` : `最长 Task · ${longest.leaf}`,
    note: `${ms(longest.spanUs)} ms 跨度`,
    t0: longest.startUs, t1: longest.endUs, hot: sameAsLongest && lens === "wait", id: longest.id,
  });
  if (cs.serial.length) {
    const r = cs.serial[0];
    out.push({ label: `最长串行段 · 全机只有 ≤2 核在跑`, note: `${ms(r.t1 - r.t0)} ms，其余 ${R.kpi.totalCores - 2} 核空转`,
               t0: r.t0, t1: r.t1, hot: false, id: null });
  }
  if (top && !sameAsLongest) {
    if (lens === "tail") {
      const ends = (top.blocks.items || []).map((b) => b.endUs).sort((a, b) => a - b);
      if (ends.length > 1) {
        const t0 = ends[Math.floor(ends.length / 2)], t1 = ends[ends.length - 1];
        out.push({ label: `尾块拖尾 · ${top.leaf}`, note: `一半块结束后又跑了 ${ms(t1 - t0)} ms`,
                   t0, t1, hot: false, id: top.id });
      }
    } else {
      out.push({ label: `${LENS[lens].label} Top1 · ${top.leaf}`, note: lensMetric(top),
                 t0: top.startUs, t1: top.endUs, hot: lens === "wait", id: top.id });
    }
  }
  return out;
}

// Greedy interval packing per core type: a task goes in the first track whose
// last task has already finished. Track count = peak simultaneous tasks.
function packTasks() {
  const lane = new Map(), depth = {};
  for (const ct of ["AIC", "AIV"]) {
    const ls = R.launches.filter((l) => l.ct === ct && (!laneRange || (l.endUs > laneRange[0] && l.startUs < laneRange[1])))
      .sort((a, b) => a.startUs - b.startUs || b.spanUs - a.spanUs);
    const ends = [];
    for (const l of ls) {
      let i = ends.findIndex((e) => e <= l.startUs + 1e-9);
      if (i < 0) { ends.push(l.endUs); i = ends.length - 1; } else ends[i] = l.endUs;
      lane.set(l.id, i);
    }
    depth[ct] = Math.max(1, ends.length);
  }
  return { lane, depth };
}

let pathAnalysisActive = true;
const TASK_LAYERS = [
  ["recommended", "系统推荐 · 多类型"], ["none", "关闭"], ["tail", "拖尾任务"], ["parallel", "Task 并行度不足"],
  ["imbalance", "块负载不均"], ["underfill", "尾波空置"], ["fragmented", "离散小 Task"],
  ["setup", "Setup 占比高"], ["bubble", "依赖间隔"],
];
function analyzeTaskLayer(mode) {
  if (mode === "recommended") return recommendTaskGroups();
  const tasks = R.launches, hits = new Set(), gaps = [];
  const sorted = (values) => values.slice().sort((a, b) => a - b);
  const quantile = (values, q) => {
    const a = sorted(values);
    return a.length ? a[Math.min(a.length - 1, Math.floor((a.length - 1) * q))] : 0;
  };
  const p50Span = quantile(tasks.map((l) => l.spanUs), .5);
  const p25Span = quantile(tasks.map((l) => l.spanUs), .25);
  const p25BlockCount = quantile(tasks.map((l) => l.blocks.n), .25);
  const p90End = quantile(tasks.map((l) => l.endUs), .9);
  const byTask = new Map(tasks.map((l) => [String(l.taskId), l]));
  const predEdges = new Map();
  if (mode === "bubble") R.edges.forEach((e) => {
    const key = String(e.succ);
    if (!predEdges.has(key)) predEdges.set(key, new Set());
    predEdges.get(key).add(String(e.pred));
  });

  for (const l of tasks) {
    const cores = l.ct === "AIC" ? R.kpi.aicCores : R.kpi.aivCores;
    const setupShare = l.setupUs / Math.max(1, l.computeUs + l.setupUs);
    const lastWave = cores ? l.blocks.n % cores : 0;
    let match = false;
    if (mode === "tail") match = l.endUs >= p90End && l.spanUs >= p50Span;
    if (mode === "parallel") match = l.blocks.n > 1 && l.spanUs >= p50Span
      && l.computeUs / Math.max(1, l.spanUs) < cores * .25 && setupShare < .5;
    if (mode === "imbalance") match = l.blocks.n >= 4 && l.blocks.spread >= 1.5
      && l.blocks.p90 / Math.max(1, l.blocks.p50) >= 1.4;
    if (mode === "underfill") match = l.waves > 1 && lastWave > 0
      && lastWave / Math.max(1, cores) < .5;
    if (mode === "fragmented") match = l.blocks.n <= Math.max(4, p25BlockCount) && l.spanUs <= p25Span;
    if (mode === "setup") match = setupShare >= .3 && l.setupUs > 1;
    if (mode === "bubble") {
      const ids = [...(predEdges.get(String(l.taskId)) || [])];
      const preds = ids.map((id) => byTask.get(id));
      if (preds.length && preds.every(Boolean)) {
        const ready = Math.max(...preds.map((p) => p.endUs));
        const gap = l.startUs - ready;
        if (gap > Math.max(3, l.blocks.p50 * 2)) {
          match = true;
          gaps.push({ task: l, t0: ready, t1: l.startUs, gap });
        }
      }
    }
    if (match) hits.add(l.id);
  }
  const labels = {
    tail: "结束时间靠后的长任务", parallel: "平均并行计算核数低于该类核的 25%",
    imbalance: "块耗时离散且 P90 明显高于中位数", underfill: "末波使用不足一半的该类型可用核",
    fragmented: "跨度和块数均处于当前 rank 的较低四分位", setup: "Setup 占计算与 Setup 总耗时的 30% 以上",
    bubble: "前驱结束到该任务开始之间存在可观测间隔（仅作线索）",
  };
  const byKernel = new Map();
  tasks.filter((l) => hits.has(l.id)).forEach((l) => {
    const kernel = l.leaf.replace(/_\d+$/, ""), key = `${l.ct} · ${kernel}`;
    if (!byKernel.has(key)) byKernel.set(key, { key, kernel, ct: l.ct, tasks: [] });
    byKernel.get(key).tasks.push(l);
  });
  const groups = [...byKernel.values()].map((group) => {
    group.tasks.sort((a, b) => a.startUs - b.startUs || b.endUs - a.endUs);
    group.totalSpan = group.tasks.reduce((sum, task) => sum + task.spanUs, 0);
    return group;
  }).sort((a, b) => b.tasks.length - a.tasks.length || b.totalSpan - a.totalSpan);
  return { hits, gaps, groups, label: labels[mode] || "", count: mode === "bubble" ? gaps.length : hits.size };
}

function taskLayerColor(mode) {
  // Reuse CSA Pass Field's anomaly, task, weight, gradient, memory,
  // aggregate and communication colors; each feature has a distinct key.
  return ({ tail: "#fd5644", parallel: "#9ef04b", imbalance: "#bca0f3", underfill: "#79d4f2",
    fragmented: "#087cfa", setup: "#f2c45f", bubble: "#33c69a" })[mode] || C.candidate;
}
// Menu keys share the semantic colors used by lane envelopes and labels.
function taskLayerSwatch(mode) {
  if (mode === "none") return '<span class="feature-swatch is-off" aria-hidden="true"></span>';
  const colors = mode === "recommended"
    ? [...new Set(TASK_LAYERS.filter(([v]) => !["none", "recommended"].includes(v)).map(([v]) => taskLayerColor(v)))]
    : [taskLayerColor(mode)];
  return `<span class="feature-swatches" aria-hidden="true">${colors.map(color => `<i class="feature-swatch" style="--feature-color:${color}"></i>`).join("")}</span>`;
}
function taskFeatureName(mode) {
  return mode === "tail" ? "末段长任务" : (TASK_LAYERS.find(([value]) => value === mode)?.[1] || mode);
}
function recommendTaskGroups() {
  if (R._recommendations) return R._recommendations;
  const merged = new Map(), gaps = [];
  const criticalIds = new Set(R.criticalPath.flatMap((p) => [String(p.taskId), ...(p.ids || [])]));
  for (const [mode] of TASK_LAYERS.filter(([value]) => !["none", "recommended"].includes(value))) {
    const analysis = analyzeTaskLayer(mode);
    gaps.push(...analysis.gaps);
    analysis.groups.forEach((group) => {
      if (!merged.has(group.key)) merged.set(group.key, { ...group, tasks: [], modes: [], evidence: [], score: 0 });
      const item = merged.get(group.key);
      const span = Math.max(...group.tasks.map((task) => task.spanUs));
      const setup = group.tasks.reduce((sum, task) => sum + task.setupUs, 0);
      const compute = group.tasks.reduce((sum, task) => sum + task.computeUs, 0);
      const cores = group.ct === "AIC" ? R.kpi.aicCores : R.kpi.aivCores;
      let severity = span / R.kpi.windowUs, reason = "";
      if (mode === "tail") reason = "运行窗口末段的长任务，跨度 " + ms(span) + " ms";
      if (mode === "parallel") {
        const average = Math.max(...group.tasks.map((task) => task.computeUs / Math.max(1, task.spanUs)));
        severity *= Math.max(0, 1 - average / cores);
        reason = "平均计算并行宽度最高 " + average.toFixed(1) + " / " + cores + " 核";
      }
      if (mode === "imbalance") {
        const spread = Math.max(...group.tasks.map((task) => task.blocks.spread));
        severity *= Math.min(2, spread - 1);
        reason = "最慢块 / 平均块最高 " + spread.toFixed(1) + "×";
      }
      if (mode === "underfill") {
        const share = Math.min(...group.tasks.map((task) => (task.blocks.n % cores) / cores));
        severity *= (1 - share) * .6;
        reason = "按块数推算，末波核填充最低 " + Math.round(share * 100) + "%";
      }
      if (mode === "fragmented") {
        severity = group.tasks.length * .006 + setup / R.kpi.windowUs * .1;
        reason = group.tasks.length + " 次短提交，累计 Setup " + ms(setup) + " ms 核时";
      }
      if (mode === "setup") {
        const share = setup / Math.max(1, setup + compute);
        severity *= share;
        reason = "Setup占比 " + Math.round(share * 100) + "%";
      }
      if (mode === "bubble") {
        const gap = Math.max(0, ...analysis.gaps.filter((g) => group.tasks.some((task) => task.id === g.task.id)).map((g) => g.gap));
        severity = gap / R.kpi.windowUs;
        reason = "前驱就绪至启动的最长观测间隔 " + ms(gap) + " ms";
      }
      const onPath = group.tasks.some((task) => criticalIds.has(task.id) || criticalIds.has(String(task.taskId)));
      const score = severity;
      item.modes.push(mode);
      item.evidence.push({ mode, score, reason });
      item.score = Math.max(item.score, score);
      item.onPath ||= onPath;
      group.tasks.forEach((task) => { if (!item.tasks.some((other) => other.id === task.id)) item.tasks.push(task); });
    });
  }
  // Keep path-connected findings ahead of secondary findings. Same kernel is one
  // attention point even when it matches several rules; scores are not savings.
  const pool = [...merged.values()], selected = [], covered = new Set();
  while (pool.length && selected.length < 5) {
    pool.sort((a, b) => Number(b.onPath) - Number(a.onPath)
      || (b.score + (b.modes.some((mode) => !covered.has(mode)) ? .025 : 0))
        - (a.score + (a.modes.some((mode) => !covered.has(mode)) ? .025 : 0))
      || a.key.localeCompare(b.key));
    const group = pool.shift();
    group.evidence.sort((a, b) => b.score - a.score);
    group.primaryMode = group.evidence[0].mode;
    group.rank = selected.length + 1;
    group.modes.forEach((mode) => covered.add(mode));
    selected.push(group);
  }
  const hits = new Set(selected.flatMap((group) => group.tasks.map((task) => task.id)));
  const pathCount = selected.filter((group) => group.onPath).length;
  R._recommendations = { groups: selected, hits, gaps: gaps.filter((gap) => hits.has(gap.task.id)),
    count: hits.size, totalGroups: merged.size, pathCount,
    label: "系统推荐：关键路径关联项优先，路径外分布异常补位；仅作分析线索" };
  return R._recommendations;
}

function renderRecommendations() {
  const analysis = recommendTaskGroups();
  const groups = analysis.groups.filter(group => candidateFilter === "recommended" || group.modes.includes(candidateFilter));
  const panel = $("recommendations"); panel.hidden = false;
  $("analysis-panel-anchor").append($("task-drawer"));
  panel.innerHTML = groups.map(group => '<button type="button" class="recommendation" data-recommendation="' + esc(group.key)
    + '" aria-pressed="' + (recommendedFocus === group.key) + '"><strong>' + esc(group.kernel)
    + '</strong><small>' + esc((group.evidence.find(item => item.mode === candidateFilter) || group.evidence[0]).reason) + '</small></button>').join("")
    || '<p style="padding:20px 0">当前运行没有符合此特征的候选任务。</p>';

}
// Curated compile evidence is local and independent of the selected runtime rank.
let passReturnKey = null, passKernel = null, passReturnTask = false, passMode = "kernel", setupCore = null;
let memoryBuffer = "mem_vec_15", memoryValue = null;
let passStepIndex = 0, passObjectId = null, passDependencyStage = 'P09';
const PASS_LABELS = { csa_merge_pack_publish: "执行前等待 · 依赖来源",
  qr_hadamard_matmul: "Tile · 布局 · 输入搬运", qr_hadamard_quant: "两轮读取 · 缓冲 · 量化搬运" };
function passEntry(key, kernel) {
  return PASS_LABELS[kernel] ? '<button type="button" class="pass-entry" data-pass-analysis="' + esc(key)
    + '" aria-haspopup="dialog"><span>' + (kernel === 'csa_merge_pack_publish' ? '查看等待归因' : '查看 Pass 分析') + ' <small>' + PASS_LABELS[kernel]
    + '</small></span><span aria-hidden="true">↗</span></button>' : '';
}
function passSource(source) {
  const name = source.path.split("/").pop();
  const indent = Math.min(...source.lines.map(item => item.text.match(/^\s*/)[0].length));
  const code = source.lines.map(({ line, text }) => '<span class="pass-line'
    + (text.includes("pl.system.fence()") ? ' added' : '') + '"><em>' + line + '</em>'
    + esc(text.slice(indent)) + '</span>').join("");
  return '<article class="pass-source"><header>' + esc(source.label)
    + '<a href="../../' + esc(source.path) + '" target="_blank" rel="noopener" title="'
    + esc(source.path) + '">' + esc(name) + ' · L' + source.lines.map(item => item.line).join(', L')
    + ' ↗</a></header><pre tabindex="0" aria-label="' + esc(source.label) + ' 原始代码摘录，可横向滚动"><code>' + code + '</code></pre></article>';
}
function activePassAnalysis() {
  if (passMode === "diagnostic") return window.PERF_PASS_ANALYSIS?.independentCases?.memoryReuse;
  const entry = window.PERF_PASS_ANALYSIS?.cases?.[passKernel];
  return passMode === "setup" ? entry?.setupAnalysis : entry;
}
function setupRuntime() {
  return window.PERF_PASS_ANALYSIS?.cases?.[passKernel]?.setupAnalysis?.ranks?.[R.rank];
}
function currentObjectScene() {
  return window.PERF_PASS_OBJECTS?.sceneFor(passKernel, passMode, passStepIndex, passDependencyStage);
}
function objectSources(scene, object) {
  const step = activePassAnalysis()?.steps[passStepIndex];
  const sources = scene.sources ? scene.sources.map(i => step.sources[i]).filter(Boolean) : step.sources;
  const match = [...new Set([...object.match, ...(scene.before.nodes.find(node => node.id === object.id)?.match || []), ...(scene.after.nodes.find(node => node.id === object.id)?.match || [])])];
  return [...sources, ...(step.diagnostic?.sources || [])].map(source => {
    let lines = source.lines.filter(line => match.some(needle => line.text.includes(needle)));
    if (/^fence[01]$/.test(object.id)) lines = lines.slice(Number(object.id.slice(-1)), Number(object.id.slice(-1)) + 1);
    return { ...source, lines };
  }).filter(source => source.lines.length);
}
function passObjectInspector() {
  const scene = currentObjectScene(), object = scene && window.PERF_PASS_OBJECTS.object(scene, passObjectId);
  if (!object) return '';
  const before = scene.before.nodes.find(node => node.id === object.id), after = scene.after.nodes.find(node => node.id === object.id);
  const sources = objectSources(scene, object);
  return '<div class="object-inspector-head"><span>当前观测对象</span><strong>' + esc(object.title) + '</strong><code>' + esc(object.id) + '</code></div>'
    + '<div class="object-property"><span>' + esc(before?.sub || '此快照中不存在') + '</span><b aria-hidden="true">→</b><span>' + esc(after?.sub || '此快照中不存在') + '</span></div>'
    + (sources.length ? '<details class="pass-disclosure"><summary>关联原始代码 · ' + sources.length + ' 个片段</summary><div class="pass-sources">'
      + sources.map(passSource).join('') + '</div></details>' : '<small>此对象用于展示上下文；完整快照见下方原始证据。</small>');
}
function passObjectVisual(scene) {
  if (!window.PERF_PASS_OBJECTS.object(scene, passObjectId)) passObjectId = (scene.after.nodes.find(node => node.state !== 'same') || scene.after.nodes[0]).id;
  const stages = passMode === 'setup' ? '<div class="object-snapshots" aria-label="选择编译快照">'
    + [['P00','前端'],['P09','外提 kernel'],['P10','形成提交'],['P40','依赖推导']].map(([id,label]) => '<button type="button" class="ctl'
      + (passDependencyStage === id ? ' on' : '') + '" data-pass-snapshot="' + id + '" aria-pressed="' + (passDependencyStage === id) + '">'
      + id + ' · ' + label + '</button>').join('') + '</div>' : '';
  return stages + window.PERF_PASS_OBJECTS.render(scene, passObjectId) + '<section class="object-inspector" id="pass-object-inspector" aria-label="对象前后属性与关联代码">' + passObjectInspector() + '</section>';
}
function selectPassObject(id) {
  const scene = currentObjectScene();
  if (!scene || !window.PERF_PASS_OBJECTS.object(scene, id)) return;
  passObjectId = id;
  $("pass-evidence").querySelectorAll('[data-pass-object]').forEach(node => {
    const selected = node.dataset.passObject === id;
    node.classList.toggle('selected', selected);
    node.setAttribute('aria-pressed', String(selected));
  });
  $("pass-object-inspector").innerHTML = passObjectInspector();
}
function setupBlockDetail() {
  const runtime = setupRuntime(), block = runtime?.blocks.find(item => item.core === setupCore);
  if (!block) return '';
  const us = value => value.toFixed(2) + ' μs';
  return '<h4>Core ' + block.core + ' · 当前选中 block</h4><dl><dt>本核 qk_pv 结束</dt><dd>' + us(block.previousEnd)
    + '</dd><dt>领取当前任务</dt><dd>' + us(block.receive) + '</dd><dt>当前 kernel 开始</dt><dd>' + us(block.start)
    + '</dd><dt>Setup / kernel 执行</dt><dd>' + us(block.setup) + ' / ' + us(block.kernel)
    + '</dd><dt>记录定位</dt><dd>aicore_tasks[' + block.recordIndex + ']</dd></dl>'
    + '<button type="button" class="ctl" data-pass-step="2">追溯 Pass 中的依赖 →</button>';
}
function setupVisual(kind) {
  const runtime = setupRuntime();
  if (!runtime) return '<p>当前 rank 缺少原始 block 证据。</p>';
  const us = value => value.toFixed(2) + ' μs';
  const links = '<p class="setup-source"><a target="_blank" rel="noopener" href="../../' + esc(runtime.rawPath)
    + '">原始 block 与调度记录 ↗</a> · <a target="_blank" rel="noopener" href="../../' + esc(runtime.depsPath) + '">实际依赖归档 ↗</a></p>';
  if (kind === 'totals') return '<div class="setup-ratio"><strong>' + (runtime.overlapShare * 100).toFixed(2) + '%</strong><span>Setup 核时位于 qk_pv 最后执行结束之前</span><div class="setup-ratio-bar" role="img" aria-label="前驱执行结束前覆盖比例 ' + (runtime.overlapShare * 100).toFixed(2) + '%"><i style="width:' + (runtime.overlapShare * 100).toFixed(4) + '%"></i></div><div class="setup-ratio-legend"><span>■ 前驱尚未完成时的覆盖区间</span><span>□ 剩余区间</span></div></div><div class="object-deltas"><span>同核前驱结束 → 领取 ' + runtime.pickupGapMin.toFixed(2) + '～' + runtime.pickupGapMax.toFixed(2) + ' μs</span><span>前驱被记录完成 → kernel 开始 · 平均 ' + runtime.residualMean.toFixed(2) + ' μs</span></div><details class="pass-disclosure"><summary>展开计时明细与计算口径</summary><div class="pass-facts"><table><caption>' + esc(R.rank) + ' · 原始周期换算，按各 block 累加</caption><tbody>'
    + [['Setup 核时', us(runtime.setup)], ['前驱执行结束前覆盖的核时', us(runtime.beforeEnd)],
      ['覆盖比例（非精确等待计数）', (runtime.overlapShare * 100).toFixed(2) + '%'],
      ['调度器记录前驱完成后，至 kernel 开始的平均间隔', us(runtime.residualMean)],
      ['本核前驱结束 → 领取间隔', us(runtime.pickupGapMin) + ' ～ ' + us(runtime.pickupGapMax)]]
      .map(row => '<tr><th>' + esc(row[0]) + '</th><td>' + esc(row[1]) + '</td></tr>').join('') + '</tbody></table></div>'
    + '<p>覆盖核时 = Σ max(0, qk_pv 最后执行结束 − block 领取时间)。覆盖比例不等于逐事件测得的等待耗时。</p>' + links + '</details>';
  if (kind === 'actions') return '<div class="analysis-routes"><button type="button" class="analysis-route" data-setup-upstream><small>运行时 + 依赖粒度</small><strong>追查执行前等待</strong><span>qk_pv 收尾 → 等待释放 → 当前 kernel 开始</span><b>在泳道中查看 qk_pv ↗</b></button>'
    + '</div>' + links;
  const first = Math.min(...runtime.blocks.map(block => block.receive)) - 8;
  const last = Math.max(...runtime.blocks.map(block => block.end)) + 8, span = last - first;
  const at = value => ((value - first) / span * 100).toFixed(4);
  if (!runtime.blocks.some(block => block.core === setupCore)) setupCore = runtime.blocks.reduce((a, b) => a.setup > b.setup ? a : b).core;
  return '<div class="setup-chart"><p class="setup-legend"><span>■ 执行前区间（含等待）</span><span>■ kernel 执行</span><span>┆ qk_pv 最后执行结束</span></p>'
    + '<div class="setup-axis"><span>' + us(first) + '</span><span>' + us(last) + '</span></div>'
    + '<div class="setup-rows" role="group" aria-label="48 个 block 的领取与执行时序">' + runtime.blocks.map(block =>
      '<button type="button" class="setup-row" data-setup-core="' + block.core + '" aria-pressed="' + (setupCore === block.core)
      + '" title="Core ' + block.core + '：领取 ' + us(block.receive) + '；执行开始 ' + us(block.start) + '；Setup ' + us(block.setup)
      + '"><span>Core ' + block.core + '</span><span class="setup-track"><i class="setup-prep" style="left:' + at(block.receive) + '%;width:'
      + (block.setup / span * 100).toFixed(4) + '%"></i><i class="setup-kernel" style="left:' + at(block.start) + '%;width:'
      + (block.kernel / span * 100).toFixed(4) + '%"></i><i class="setup-ready" style="left:' + at(runtime.predEnd)
      + '%"></i></span></button>').join('') + '</div></div><p>qk_pv 最后执行结束：' + us(runtime.predEnd)
    + '；调度器最后记录完成：' + us(runtime.predFinish) + '。时间与当前 rank 的原始设备记录对齐。</p>'
    + '<div class="setup-detail" id="setup-detail">' + setupBlockDetail() + '</div>' + links;
}
function renderPassStep(index) {
  const payload = window.PERF_PASS_ANALYSIS, data = activePassAnalysis();
  if (!data || payload.run !== D.run || !data.steps[index]) return;
  const step = data.steps[index];
  passStepIndex = index;
  const objectScene = currentObjectScene();
  $("pass-boundary").textContent = data.boundary;
  $("pass-branches").hidden = true;
  $("pass-branches").innerHTML = '';
  $("pass-nav").innerHTML = '<p>' + (passMode === 'diagnostic' ? '独立编译诊断 · 结构与证据' : passMode === 'setup' ? '实测现象 → 归因 → Pass 来源' : '同一 kernel · 按编译顺序追溯') + '</p>' + data.steps.map((item, i) =>
    '<button type="button" class="pass-step" data-pass-step="' + i + '"'
    + (i === index ? ' aria-current="step"' : '') + '><span>' + item.pass + '</span><strong>'
    + esc(item.title) + '</strong><small>' + esc(item.name) + '</small></button>').join("");
  $("pass-evidence").innerHTML = '<div class="pass-step-heading"><span>' + esc(step.pass) + '</span><h3>' + esc(step.title) + '</h3></div>'
    + (passMode === "diagnostic" ? window.MEMORY_REUSE_CASE.render(data, index, memoryBuffer, memoryValue, passSource) : objectScene ? passObjectVisual(objectScene) : (step.visual ? setupVisual(step.visual) : '<p>' + esc(step.summary) + '</p>'))
    + (step.diagnostic ? '<div class="object-diagnostic"><span>! ' + esc(step.diagnostic.title) + '</span><span>完整告警见展开说明</span></div>' : '')
    + '<details class="pass-disclosure"><summary>解释、原始快照与完整告警</summary><p>' + esc(step.finding) + '</p>'
    + (step.facts ? '<div class="pass-facts"><table><caption>静态形状与搬运口径</caption><thead><tr><th>对象</th><th>形状 / 路径</th><th>字节数 / 布局</th></tr></thead><tbody>'
      + step.facts.map(row => '<tr>' + row.map(cell => '<td>' + esc(cell) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>' : '')
    + (step.diagnostic ? '<aside class="pass-warning"><b>' + esc(step.diagnostic.title) + '</b><p>' + esc(step.diagnostic.text)
      + '</p><details><summary>查看完整告警与源码位置映射</summary>' + step.diagnostic.sources.map(passSource).join('')
      + '<p>' + esc(step.diagnostic.note) + '</p></details></aside>' : '')
    + '<div class="pass-sources">' + step.sources.map(passSource).join("") + '</div><p>' + esc(step.next) + '</p></details>'
    + (index < data.steps.length - 1 ? '<button type="button" class="ctl" data-pass-step="' + (index + 1)
      + '">继续到 ' + data.steps[index + 1].pass + ' →</button>' : '');
  $("pass-evidence").scrollTop = 0;
  if (step.visual === 'blocks') $("pass-evidence").querySelector('[data-setup-core="' + setupCore + '"]')?.scrollIntoView({ block: 'nearest' });
  $("pass-evidence").scrollTop = 0;
}
function openMemoryReuseCase() {
  passReturnKey = 'memoryreuse-depth'; passReturnTask = false;
  passKernel = 'memoryreuse-depth'; passMode = 'diagnostic';
  memoryBuffer = 'mem_vec_15'; memoryValue = null; passObjectId = null;
  const data = activePassAnalysis(), dialog = $("pass-dialog");
  $("pass-title").textContent = '独立编译诊断 · P35 MemoryReuse';
  $("pass-context").textContent = 'csa_merge_pack_publish · group 0 · Vec · 编译快照';
  $("pass-context").title = D.run;
  $("pass-runtime").innerHTML = '<span>请求隔离深度 <b>2</b></span><span>实际满足 <b>1</b></span><span>每阶段 <b>32 KiB</b></span><span>可规划容量 <b>184 KiB</b></span>';
  if (data && window.PERF_PASS_ANALYSIS.run === D.run) renderPassStep(0);
  else { $("pass-nav").textContent = '编译证据不可用'; $("pass-evidence").textContent = '缺少当前运行的独立案例数据，请检查 data/pass-analysis.js。'; $("pass-branches").hidden = true; $("pass-boundary").textContent = ''; }
  if (!dialog.open) dialog.showModal();
  dialog.querySelectorAll('[title]').forEach(node=>{node.dataset.tooltip=node.getAttribute('title');node.removeAttribute('title');});
  requestAnimationFrame(()=>dialog.querySelector('[data-setup-core][aria-pressed="true"]')?.scrollIntoView({block:'nearest'}));
  $("pass-close").focus();
}
function openPassAnalysis(key) {
  const group = recommendTaskGroups().groups.find(item => item.key === key && PASS_LABELS[item.kernel]);
  const task = group?.tasks[0] || R.launches.find(item => key === 'task:' + item.id && PASS_LABELS[item.leaf]);
  if (!task) return;
  passReturnKey = key;
  passReturnTask = !group;
  passKernel = task.leaf;
  passObjectId = null; passDependencyStage = 'P09';
  passMode = window.PERF_PASS_ANALYSIS?.cases?.[passKernel]?.setupAnalysis ? 'setup' : 'kernel';
  setupCore = null;
  if (group && recommendedFocus !== key) focusRecommendation(key);
  setDrawer(false);
  const dialog = $("pass-dialog"), payload = window.PERF_PASS_ANALYSIS, analysis = payload?.cases?.[passKernel];
  $("pass-title").textContent = 'Pass 分析 · ' + passKernel;
  $("pass-boundary").textContent = analysis?.boundary || '归因边界：编译证据尚未证明当前性能异常的原因，需结合运行时对照分析。';
  $("pass-context").textContent = R.rank + ' · Task #' + task.taskId;
  $("pass-context").title = D.run;
  const share = task.setupUs / Math.max(1, task.setupUs + task.computeUs) * 100;
  const focusMetric = passKernel === 'csa_merge_pack_publish' ? '<span>Setup（含执行前等待）占比 <b>' + share.toFixed(0) + '%</b></span>'
    : '<span>平均计算并行度 <b>' + (task.computeUs / Math.max(1, task.spanUs)).toFixed(1) + ' / ' + task.availCores
      + ' 核</b></span><span>最慢 / 平均块 <b>' + task.blocks.spread.toFixed(1) + '×</b></span>';
  $("pass-runtime").innerHTML = '<span>领取至结束跨度 <b>' + ms(task.spanUs) + ' ms</b></span>' + focusMetric + '<span>kernel 执行核时 <b>' + ms(task.computeUs)
    + ' ms</b></span><span>提交规模 <b>' + task.blocks.n + ' blocks</b></span>';
  if (!analysis || payload.run !== D.run) {
    $("pass-branches").hidden = true;
    $("pass-nav").textContent = '编译证据不可用';
    $("pass-evidence").innerHTML = '<h3>未找到当前运行的 Pass 证据</h3><p>请确认 Demo 的 data/pass-analysis.js 文件完整，并与当前运行对应。</p>';
  } else renderPassStep(0);
  if (!dialog.open) dialog.showModal();
  dialog.querySelectorAll('[title]').forEach(node=>{node.dataset.tooltip=node.getAttribute('title');node.removeAttribute('title');});
  requestAnimationFrame(()=>dialog.querySelector('[data-setup-core][aria-pressed="true"]')?.scrollIntoView({block:'nearest'}));
  $("pass-close").focus();
}
function focusRecommendation(key) {
  const group = recommendTaskGroups().groups.find(item => item.key === key);
  if (!group) return;
  if (recommendedFocus === key) { clearSelection(); return; }
  recommendedFocus = key;
  me = group.tasks[0].id;
  laneComposition = false;
  paint(); setDrawer(true);
}
function clearSelection() {
  qkInline=null;qkReturnView=null;
  const restoreSingleScroll = singleSelected != null ? singlePreviousScroll : null;
  if (singleSelected != null) { laneRange = singlePreviousRange; singlePreviousRange = null; singleSelected = null; renderSinglePanel(); }
  me = null; recommendedFocus = null; laneComposition = false; setDrawer(false); paint();
  if (restoreSingleScroll != null) $('lane-wrap').scrollTop = restoreSingleScroll;
}

function renderLane() {
  syncSingleScrollSpace();
  $('single-analysis-button').setAttribute('aria-pressed', String(singlePanelOpen));
  document.body.classList.toggle("core-pipeline-active",!!qkInline);
  window.QK_PASS_EVOLUTION?.stop();window.INLINE_PASS_TRANSFORM?.stop();
  const showPathLane=pathAnalysisActive&&!document.body.classList.contains('compile-analysis-mode');
  document.body.classList.toggle('show-path-lane',showPathLane);
  if(showPathLane)criticalPath();
  // Refresh the shared critical-path navigation after the lane render.
  queueMicrotask(() => window.CriticalPathIntegration?.refresh());
  const svg = $("lane"), axis = $("lane-axis"), LEFT = laneLeft(), RIGHT = 12, TOP = 10;
  $("lane-wrap").classList.toggle("can-pan", !!laneRange);
  const W = Math.max(600, Math.floor($("lane-wrap").clientWidth || 600));
  const byTask = laneView === "task";
  const compositionGroup = laneComposition && recommendedFocus
    ? recommendTaskGroups().groups.find((group) => group.key === recommendedFocus) : null;
  const compositionIds = compositionGroup ? new Set(compositionGroup.tasks.map((task) => task.id)) : null;
  const resultsActive = $("analysis-panel-anchor").classList.contains("results-open");
  const activeLayer = (qkInline||document.body.classList.contains("compile-analysis-mode")) ? "none" : pathAnalysisActive || resultsActive ? "recommended" : taskLayer;
  const taskAnalysis = activeLayer !== "none"
    ? { ...analyzeTaskLayer(activeLayer) } : { hits: new Set(), gaps: [], groups: [], label: "", count: 0 };
  if (pathAnalysisActive) {
    taskAnalysis.groups = taskAnalysis.groups.flatMap(group => R.criticalPath.flatMap((p,i) => {
      const tasks=group.tasks.filter(t=>String(t.taskId)===String(p.taskId));
      return tasks.length ? [{...group,key:group.key+':path:'+p.taskId,kernel:p.name,rank:i+1,tasks}] : [];
    }));
    taskAnalysis.hits = new Set(taskAnalysis.groups.flatMap(g=>g.tasks.map(t=>t.id)));
  }
  const taskProfileColor = taskLayerColor(taskLayer);
  renderRecommendations(!byTask && taskLayer === "recommended" ? taskAnalysis : null);
  // Keep chart typography stable in CSS pixels: on wide screens the time axis
  // gains horizontal room instead of scaling the entire SVG and making rows taller.
  const labelScale = Math.max(1, (svg.clientWidth || W) / W);
  const taskLabelFont = 12 / labelScale;
  const taskLabelAdvance = 7.2 / labelScale;
  const coreRows = R.cores.slice().sort((a, b) => a.id - b.id);
  const pk = byTask ? packTasks() : null;
  // Task lanes need a little more vertical breathing room as the time axis
  // grows on wide/high-resolution screens; keep a bounded row height so the
  // compact view remains usable on both normal and ultra-wide displays.
  const taskRow = 38;
  const baseROW = byTask ? taskRow : 8;
  const GH = byTask ? 36 : 0;                       // room for a group caption line
  const rowCount = byTask ? pk.depth.AIC + pk.depth.AIV : coreRows.length;
  const aicCoreCount = byTask ? 0 : coreRows.filter((core) => core.ct === "AIC").length;
  const CORE_GROUP_H = byTask ? 0 : 36;
  const innerW = W - LEFT - RIGHT, win = R.kpi.windowUs, cs = concStats();
  const viewStart = laneRange ? laneRange[0] : 0;
  const viewEnd = laneRange ? laneRange[1] : win;
  const viewWin = Math.max(1e-6, viewEnd - viewStart);
  const metricValue = (l) => laneColor === "setup" ? l.setupUs / (l.computeUs || 1) * 100 : l.tailWasteUs / 1000;
  const metricValues = laneColor === "none" ? [] : R.launches.map(metricValue).sort((a, b) => a - b);
  const metricCap = metricValues.length ? metricValues[Math.max(0, Math.ceil(metricValues.length * .9) - 1)] || 1 : 1;
  const metricColor = (l) => {
    if (laneColor === "none") return null;
    const t = Math.max(0, Math.min(1, metricValue(l) / metricCap));
    const from = 56, to = 208, v = Math.round(from + (to - from) * t);
    return `rgb(${v} ${v} ${v})`;
  };
  const marks = !qkInline && ovl.marks && pathAnalysisActive && !resultsActive ? landmarks() : [];
  const RIB = ovl.ribbon ? 60 : 0;
  const RIBGAP = !qkInline && ovl.ribbon ? 8 : 0;
  const ribbonHeading = 0;
  const laneTop = TOP + ribbonHeading + RIB + RIBGAP;
  const laneViewportH = $("lane-wrap").clientHeight || 0;
  // Expand physical-core rows to use the available viewport height. Keep the
  // compact minimum on short screens, where the lane itself remains scrollable.
  const axisHeight = document.querySelector(".lane-axis-sticky").getBoundingClientRect().height;
  const ROW = byTask ? baseROW : laneExpanded ? 28 : Math.max(1, Math.min(18,
    (laneViewportH - axisHeight - laneTop - 6 - CORE_GROUP_H * 2) / Math.max(1, rowCount)));
  const qkHero = window.QK_RESIDENCY.hero(R);
  const heroIndex = byTask ? -1 : coreRows.findIndex(c=>c.id===qkHero.core);
  const HERO_EXTRA = heroIndex>=0 ? Math.max(0,24-ROW) : 0;
  const coreHeight = index => ROW+(index===heroIndex?HERO_EXTRA:0);
  const inlineIndex = !byTask && qkInline ? coreRows.findIndex(c=>c.id===qkInline.core) : -1;
  const INLINE_H = inlineIndex>=0 ? (inlineEvolution?416:(qkInline.id.endsWith('qk_pv_aic')?380:250)) : 0;
  const coreY = index => laneTop + CORE_GROUP_H + index*ROW + (index>=aicCoreCount?CORE_GROUP_H:0) + (heroIndex>=0&&index>heroIndex?HERO_EXTRA:0) + (inlineIndex>=0&&index>inlineIndex?INLINE_H:0);
  laneRowCenters = byTask ? [] : coreRows.map((_,index)=>coreY(index)+coreHeight(index)/2);
  const laneH = byTask ? rowCount*ROW+GH*2 : rowCount*ROW+CORE_GROUP_H*2+HERO_EXTRA+INLINE_H;
  const H = laneTop + laneH + 4;
  const cand = !qkInline && pathAnalysisActive && pathVisible ? new Set(R.launches.filter(l => R.criticalPath.some(p => p.ids.includes(l.id) || String(p.taskId) === String(l.taskId))).map(l => l.id)) : new Set();
  const landmarkIds = new Set(marks.flatMap((m) => m.id ? [m.id] : []));
  const keep = (id) => laneAll || cand.has(id) || id === me || taskAnalysis.hits.has(id) || landmarkIds.has(id);
  svg.textContent = ""; svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("width", W); svg.setAttribute("height", H);
  const xOf = (us) => LEFT + ((us - viewStart) / viewWin) * innerW;
  const r1 = (v) => Math.round(v * 10) / 10;
  const txt = (o, s, parent = svg) => { const t = el("text", o); t.textContent = s; parent.append(t); return t; };
  const hit = (id, aria) => el("g", { class: "task-event", "data-id": id, tabindex: "0", role: "button",
    "aria-label": aria, style: "cursor:pointer" });
  axis.textContent = ""; axis.setAttribute("viewBox", `0 0 ${W} 22`); axis.setAttribute("width", W); axis.setAttribute("height", 22);
  axis.append(el("rect", { x: 0, y: 0, width: W, height: 22, fill: "#111111" }));
  axis.append(el("line", { x1: LEFT, x2: W - RIGHT, y1: 19, y2: 19, stroke: C.grid, "stroke-width": 1 }));
  const axisLabel = (us) => viewWin < 1000 ? `${Math.round(us)} μs`
    : `${(us / 1000).toFixed(viewWin < 10000 ? 3 : 2)} ms`;
  for (let t = 0; t <= 8; t += innerW < 1100 ? 2 : 1) {
    const x = LEFT + innerW * t / 8;
    axis.append(el("line", { x1: x, x2: x, y1: 16, y2: 21, stroke: C.grid, "stroke-width": 1 }));
    txt({ x, y: 13, fill: C.axis, "font-family": "var(--mono)", "font-size": 11,
      "text-anchor": t === 0 ? "start" : t === 8 ? "end" : "middle" }, axisLabel(viewStart + viewWin * t / 8), axis);
  }

  // 1. low-concurrency bands, full height so a dip in the ribbon and a hole in
  //    the lane read as one column of time
  if (!qkInline && ovl.bands && pathAnalysisActive && !resultsActive) {
    const bandTop = laneTop, bandBot = laneTop + laneH;
    const band = (r, fill, stroke, label) => {
      const t0 = Math.max(viewStart, r.t0), t1 = Math.min(viewEnd, r.t1);
      if (t1 <= t0) return;
      const x = xOf(t0), w = Math.max(1, xOf(t1) - xOf(t0));
      const area = el("rect", { x, y: bandTop, width: w, height: bandBot - bandTop, fill });
      const title = el("desc", {}); title.textContent = `${label} · ${ms(r.t1 - r.t0)} ms`;
      area.append(title); svg.append(area);
      svg.append(el("line", { x1: x, x2: x, y1: bandTop, y2: bandBot, stroke, "stroke-opacity": .72, "stroke-width": 1.2 }));
      svg.append(el("line", { x1: x + w, x2: x + w, y1: bandTop, y2: bandBot, stroke, "stroke-opacity": .72, "stroke-width": 1.2 }));
      svg.append(el("rect", { x, y: bandTop, width: w, height: 2, fill: stroke, opacity: .68, "pointer-events": "none" }));
      if (w > 64) txt({ x: x + 4, y: bandBot + 13, fill: stroke, "font-family": "var(--mono)", "font-size": 12 }, `${label} · ${ms(r.t1 - r.t0)} ms`);
    };
    cs.serial.slice(0, 10).forEach((r) => band(r, "rgb(185 138 69 / 9%)", C.warn, "低并行 · ≤2 核"));
    cs.gaps.slice(0, 10).forEach((r) => band(r, "rgb(253 86 68 / 18%)", C.accent, "全机空闲 · 0 核"));
  }
  if (ovl.marks) marks.forEach((m) => {
    if (m.t1 < viewStart || m.t0 > viewEnd) return;
    const x0 = xOf(Math.max(viewStart, m.t0)), x1 = xOf(Math.min(viewEnd, m.t1));
    const color = m.hot ? C.accent : "#a8a8a8";
    svg.append(el("rect", { x: x0, y: laneTop, width: Math.max(1, x1 - x0), height: laneH,
      fill: m.hot ? "rgb(253 86 68 / 4%)" : "rgb(220 220 220 / 2%)", "pointer-events": "none" }));
    [x0, x1].forEach((x) => svg.append(el("line", { x1: x, x2: x, y1: laneTop, y2: laneTop + laneH,
      stroke: color, "stroke-opacity": .52, "stroke-width": 1, "pointer-events": "none" })));
  });
  if (ovl.ribbon) {
    const base = TOP + ribbonHeading + RIB, refY = base - RIB * .25;
    svg.append(el("rect", { x: LEFT, y: refY, width: innerW, height: base - refY, fill: "rgb(255 255 255 / 4%)" }));
  }

  // 2. time grid
  for (let t = 0; t <= 8; t += W < 1000 ? 2 : 1) {
    const x = LEFT + innerW * t / 8;
    svg.append(el("line", { x1: x, x2: x, y1: TOP, y2: laneTop + laneH, stroke: C.grid, "stroke-width": 1 }));
  }

  // 3. concurrency ribbon
  if (ovl.ribbon) {
    const NB = 400, bw = viewWin / NB, base = TOP + ribbonHeading + RIB, buck = new Float64Array(NB);
    for (const [a, b, c] of cs.segs) {
      if (c <= 0) continue;
      const aView = Math.max(a, viewStart), bView = Math.min(b, viewEnd);
      if (bView <= aView) continue;
      const i0 = Math.max(0, Math.floor((aView - viewStart) / bw));
      const i1 = Math.min(NB - 1, Math.ceil((bView - viewStart) / bw) - 1);
      for (let i = i0; i <= i1; i++) {
        const lo = Math.max(aView, viewStart + i * bw), hi = Math.min(bView, viewStart + (i + 1) * bw);
        if (hi > lo) buck[i] += c * (hi - lo);
      }
    }
    const total = R.kpi.totalCores || 1;
    let d = `M ${LEFT} ${base}`, topLine = "", lowLine = "";
    for (let i = 0; i < NB; i++) {
      const cores = buck[i] / bw;
      const y = r1(base - Math.min(1, cores / total) * RIB);
      const x0 = r1(LEFT + innerW * i / NB), x1 = r1(LEFT + innerW * (i + 1) / NB);
      d += ` L ${x0} ${y} L ${x1} ${y}`;
      topLine += `M ${x0} ${y} H ${x1}`;
      if (cores / total <= .25) lowLine += `M ${x0} ${y} H ${x1}`;
    }
    d += ` L ${LEFT + innerW} ${base} Z`;
    svg.append(el("path", { d, fill: "#383838" }));
    svg.append(el("path", { d: topLine, fill: "none", stroke: "#858585", "stroke-width": 1.1 }));
    if (lowLine) svg.append(el("path", { d: lowLine, fill: "none", stroke: "#c4c4c4", "stroke-width": 2, "stroke-linecap": "round" }));
    const refY = base - RIB * .25;
    svg.append(el("line", { x1: LEFT, x2: W - RIGHT, y1: refY, y2: refY, stroke: "#707070", "stroke-width": 1, "stroke-dasharray": "4 4" }));
    svg.append(el("line", { x1: LEFT, x2: W - RIGHT, y1: base, y2: base, stroke: C.grid, "stroke-width": 1 }));
    svg.append(el("circle", {cx:11, cy:TOP+10, r:11, fill:"#262626"}));
    for(let i=0;i<3;i++) svg.append(el("rect", {x:6+i*4,y:TOP+14-[4,10,7][i],width:2,height:[4,10,7][i],rx:.5,fill:"#aaa"}));
    txt({ x: 29, y: TOP + 15, fill: "#bbb", "font-family": "var(--font)", "font-size": 14 }, "并行宽度");
    txt({ x: 0, y: refY + 5, fill: C.axis, "font-family": "var(--mono)", "font-size": 12 }, `25% · ${Math.round(total * .25)} 核`);
  }

  let taskGroupLabels = null;
  // Overlay cohort footprints in the existing time/core coordinate system.
  // One contour summarizes many blocks; individual bars are not decorated.
  if (!byTask && activeLayer !== "none") {
    const rowByCore = new Map(coreRows.map((core, row) => [core.id, row]));
    const cohorts = activeLayer === "fragmented"
      ? ["AIC", "AIV"].map((ct) => ({ key: ct + " fragmented", ct, kernel: "细碎任务簇", tasks: R.launches.filter((task) => task.ct === ct && taskAnalysis.hits.has(task.id)) }))
      : taskAnalysis.groups;
    const overlay = el("g", { "pointer-events": "none", "aria-label": "Task 组空间包络" });
    const labels = [];
    cohorts.forEach((cohort) => {
      const mode = cohort.primaryMode || taskLayer, color = taskLayerColor(mode);
      const focused = pathAnalysisActive || !recommendedFocus || recommendedFocus === cohort.key;
      const clusters = [], mergeGap = Math.max(12, win * (mode === "fragmented" ? .025 : .006));
      cohort.tasks.slice().sort((a, b) => a.startUs - b.startUs).forEach((task) => {
        const last = clusters[clusters.length - 1];
        if (last && task.startUs <= last.end + mergeGap) {
          last.tasks.push(task); last.end = Math.max(last.end, task.endUs);
        } else clusters.push({ tasks: [task], end: task.endUs });
      });
      clusters.forEach((cluster) => {
        const rows = new Map();
        cluster.tasks.forEach((task) => {
          const gap = mode === "bubble" ? taskAnalysis.gaps.find((item) => item.task.id === task.id) : null;
          if (mode === "bubble" && !gap) return;
          (task.blocks.items || []).forEach((block) => {
            const row = rowByCore.get(block.core);
            const a = Math.max(viewStart, gap ? gap.t0 : block.startUs);
            const b = Math.min(viewEnd, gap ? gap.t1 : block.endUs);
            if (row == null || b <= a) return;
            const span = rows.get(row);
            if (span) { span.a = Math.min(span.a, a); span.b = Math.max(span.b, b); }
            else rows.set(row, { row, a, b });
          });
        });
        const occupied = [...rows.values()].sort((a, b) => a.row - b.row);
        if (!occupied.length) return;
        const x0 = Math.max(LEFT, xOf(Math.min(...occupied.map((row) => row.a))) - 4);
        const x1 = Math.min(W - RIGHT, xOf(Math.max(...occupied.map((row) => row.b))) + 4);
        if (mode === "parallel" || mode === "underfill") {
          const family = coreRows.map((core, row) => ({ core, row })).filter(({ core }) => core.ct === cohort.ct);
          const top = coreY(family[0].row), bottom = coreY(family[family.length - 1].row) + coreHeight(family[family.length - 1].row);
          overlay.append(el("rect", { x: x0, y: top, width: Math.max(1, x1 - x0), height: bottom - top,
            rx: 5, fill: color, "fill-opacity": .025, stroke: color,
            "stroke-opacity": .35, "stroke-dasharray": "5 5", "stroke-width": 1 }));
        }
        // Neighboring occupied rows form a lobe. Large empty core regions
        // remain open, making sparse cohorts visibly different from dense ones.
        const lobes = [];
        occupied.forEach((row) => {
          const last = lobes[lobes.length - 1];
          if (last && row.row - last[last.length - 1].row <= 3) last.push(row);
          else lobes.push([row]);
        });
        lobes.forEach((lobe) => {
          const leftPoints = [], rightPoints = [], pad = Math.min(3, ROW * .3);
          lobe.forEach((span, index) => {
            const previous = lobe[index - 1], next = lobe[index + 1];
            const top = previous ? (coreY(previous.row) + coreHeight(previous.row) + coreY(span.row)) / 2 : coreY(span.row) - pad;
            const bottom = next ? (coreY(span.row) + coreHeight(span.row) + coreY(next.row)) / 2 : coreY(span.row) + coreHeight(span.row) + pad;
            const left = Math.max(LEFT, xOf(span.a) - 4), right = Math.min(W - RIGHT, xOf(span.b) + 4);
            leftPoints.push([left, top], [left, bottom]);
            rightPoints.push([right, top], [right, bottom]);
          });
          const path = (points) => points.map(([x, y], index) => (index ? "L " : "M ") + r1(x) + " " + r1(y)).join(" ");
          overlay.append(el("path", { "data-result-region":cohort.key, d: path([...leftPoints, ...rightPoints.slice().reverse()]) + " Z",
            fill: color, "fill-opacity": focused ? (mode === "fragmented" ? .18 : .12) : .035,
            stroke: color, "stroke-opacity": focused ? .65 : .25, "stroke-width": 1.2, "stroke-linejoin": "round",
            "stroke-dasharray": mode === "fragmented" ? "2 5" : mode === "bubble" ? "6 4" : "none" }));
          if (mode === "tail" || mode === "imbalance") overlay.append(el("path", {
            d: path(rightPoints), fill: "none", stroke: color, "stroke-opacity": .9, "stroke-width": 2.4 }));
        });
        const top = coreY(occupied[0].row), bottom = coreY(occupied[occupied.length - 1].row) + coreHeight(occupied[occupied.length - 1].row);
        if ((cohort.rank || (x1 - x0 > 125 && bottom - top > 25)) && !labels.some((label) => label.key === cohort.key)) labels.push({
          key: cohort.key, icon: resultsActive || pathAnalysisActive ? TaskSemanticIcons.taskPath(cohort.kernel) : TaskSemanticIcons.featurePath(cohort.primaryMode || taskLayer), color, x: Math.min(x0, W - RIGHT - 190), y: top, width: Math.max(cohort.rank ? 190 : 0, x1 - x0),
          reason: cohort.evidence?.[0]?.reason || "", area: (x1 - x0) * (bottom - top), text: pathAnalysisActive || resultsActive ? cohort.kernel : taskFeatureName(cohort.primaryMode || taskLayer) });
      });
    });
    taskGroupLabels = el("g", { "data-lane-labels":"true", "pointer-events": resultsActive ? "auto" : "none" });
    const placedLabels = [];
    labels.sort((a, b) => b.area - a.area).slice(0, 8).forEach((label) => {
      const room = Math.min(260, label.width - 8);
      const measure = (value) => [...value].reduce((sum, ch) => sum + (ch.charCodeAt(0) > 255 ? 13 : 7.8), 0);
      let text = label.text;
      while (text.length > 4 && measure(text) > room - 38) text = text.replace(/…$/, "").slice(0, -1) + "…";
      let reason=label.reason;
      while(reason.length>4&&measure(reason)>310)reason=reason.replace(/…$/, "").slice(0,-1)+"…";
      const width = Math.min(room, measure(text) + 38);
      const fullWidth=Math.max(width,reason?Math.min(320,measure(reason)+12):0);
      const labelHeight=reason?44:24;
      label.x=Math.max(LEFT,Math.min(label.x,W-RIGHT-fullWidth-3));
      const anchorX = label.x;
      if(resultsActive && $("analysis-panel-anchor").classList.contains("inspect-open")) label.x = Math.min(label.x, Math.max(LEFT, W - 380 - width));
      let y = label.y;
      while (placedLabels.some((other) => label.x < other.x + other.width && label.x + fullWidth > other.x && y < other.y + other.height && y + labelHeight > other.y)
        && y + labelHeight*2 < laneTop + laneH) y += labelHeight;
      placedLabels.push({ x: label.x, y, width:fullWidth, height:labelHeight });
      if (y !== label.y || anchorX !== label.x) taskGroupLabels.append(el("line", { x1: label.x + 5, x2: anchorX + 5, y1: label.y, y2: y,
        stroke: label.color || taskProfileColor, "stroke-width": 1, "stroke-opacity": .6 }));
      const tag = el("g", resultsActive ? {"data-result-tag":label.key,role:"button",tabindex:0,"aria-label":label.text+" · "+label.reason,style:"cursor:pointer"} : {});
      taskGroupLabels.append(tag);
      tag.append(el("rect", { x: label.x + 3, y: y + 1, width,
        height: 22, rx: 11, fill: label.color || taskProfileColor }));
      tag.append(el("circle", {cx:label.x+15, cy:y+12, r:9, fill:"#111"}));
      tag.append(el("path", {d:label.icon, transform:`translate(${label.x+8},${y+5}) scale(${14/24})`, fill:"none", stroke:"#fff", "stroke-width":1.8, "stroke-linecap":"round", "stroke-linejoin":"round"}));
      txt({ x: label.x + 29, y: y + 16, fill: "#111111", "font-family": "var(--mono)", "font-size": 13 }, text, tag);
      if(reason){
        tag.append(el("rect",{x:label.x+3,y:y+24,width:fullWidth,height:20,rx:3,fill:"#181818","fill-opacity":.95}));
        txt({x:label.x+9,y:y+38,fill:"#c8c8c8","font-family":"var(--font)","font-size":12},reason,tag);
      }
    });
    svg.append(overlay);
  }

    const drawCoreGroup = (ct, headerY, headerHeight = 36, suffix = "") => {
      const cy = headerY + headerHeight / 2;
      svg.append(el("rect", { class:"core-group-header", x:0, y:headerY, width:W, height:headerHeight, fill:"#111111" }));
      svg.append(el("circle", { cx: 11, cy, r: 11, fill: "#262626" }));
      if (ct === "AIC") {
        for (let row = 0; row < 2; row++) for (let col = 0; col < 2; col++) {
          svg.append(el("rect", { x: 6 + col * 6, y: cy - 5 + row * 6, width: 4, height: 4,
            fill: "none", stroke: "#aaaaaa", "stroke-width": 1 }));
        }
      } else {
        for (let row = 0; row < 3; row++) svg.append(el("line", { x1: 6, x2: 16, y1: cy - 4 + row * 4, y2: cy - 4 + row * 4,
          stroke: "#aaaaaa", "stroke-width": 1 }));
      }
      txt({ x: 29, y: cy + 5, fill: "#bbbbbb", "font-family": "var(--font)", "font-size": 14 }, ct + " · " + R.kpi.byType[ct].cores + " 核 · 计算 " + (R.kpi.byType[ct].computeShare * 100).toFixed(0) + "%" + suffix);
    };
  if (byTask) {
    // ---- collapsed: one bar per submission, packed into tracks ----
    // Width encodes span; uniform height preserves task readability.
    let y0 = laneTop;
    for (const ct of ["AIC", "AIV"]) {
      const depth = pk.depth[ct], nCores = ct === "AIC" ? R.kpi.aicCores : R.kpi.aivCores;
      drawCoreGroup(ct, y0, GH, ` · ${depth} 轨`);
      const top = y0 + GH;
      for (let i = 0; i < depth; i++) {
        const yb = top + i * ROW + ROW - 3;
        svg.append(el("line", { x1: LEFT, x2: W - RIGHT, y1: yb, y2: yb, stroke: "#1e1e1e", "stroke-width": 1 }));
      }
      R.launches.filter((l) => l.ct === ct && keep(l.id)).forEach((l) => {
        const t0 = Math.max(viewStart, l.startUs), t1 = Math.min(viewEnd, l.endUs);
        if (t1 <= t0) return;
        const i = pk.lane.get(l.id), yb = top + i * ROW + ROW - 3;
        const x = xOf(t0), w = Math.max(1, ((t1 - t0) / viewWin) * innerW);
        const full = ROW - 10, h = full;
        const group = taskAnalysis.groups.find(g=>g.tasks.some(t=>t.id===l.id));
        const semanticColor = group ? taskLayerColor(group.primaryMode || taskLayer) : null;
        const isSel = l.id === me, isCand = cand.has(l.id);
        const g = hit(l.id, `${l.leaf}, ${l.ct}, ${l.coresUsed} of ${nCores} cores, ${l.spanUs} microseconds`);
        g.append(el("rect", { x, y: yb - h, width: w, height: h,
          fill: isSel ? C.sel : semanticColor || metricColor(l) || (isCand ? C.candidate : C.block), opacity: isSel || isCand || laneColor !== "none" ? 1 : .9 }));
        g.append(el("rect", { x: x - Math.max(0, (3 - w) / 2), y: top + i * ROW, width: Math.max(3, w), height: ROW, fill: "transparent" }));
        if (w > 62) {
          const onBar = h > full - 4;
          const barGray = laneColor === "none" ? (isCand ? 168 : 86)
            : Math.round(56 + 152 * Math.max(0, Math.min(1, metricValue(l) / metricCap)));
          const readableOnBar = barGray > 155 ? "#111111" : "#f2f2f2";
          const t = el("text", { x: x + 3, y: onBar ? yb - h / 2 : yb - h - 3,
            fill: isSel || semanticColor ? "#111111" : onBar ? readableOnBar : isCand ? C.candidate : "#d0d0d0",
            "font-family": "var(--mono)", "font-size": taskLabelFont,
            "dominant-baseline": onBar ? "middle" : "auto",
            "paint-order": "stroke", stroke: "#111111", "stroke-width": .35, "stroke-linejoin": "round" });
          const room = Math.max(1,Math.floor((w-28) / taskLabelAdvance));
          const pathIndex = pathAnalysisActive ? R.criticalPath.findIndex(p=>String(p.taskId)===String(l.taskId)) : -1;
          const name=(pathIndex>=0?'#'+(pathIndex+1)+' · ':'')+l.leaf;
          t.setAttribute('x',x+25);
          t.textContent = name.length > room ? `${name.slice(0, room)}…` : name;
          g.append(el('path',{d:TaskSemanticIcons.taskPath(l.leaf),transform:`translate(${x+5},${yb-h/2-8}) scale(${16/24})`,fill:'none',stroke:semanticColor||isSel?'#111':'#eee','stroke-width':1.8}));
          g.append(t);
        }
        const ttl = el("desc", {});
        ttl.textContent = `${l.leaf} · ${l.ct} · Task ${l.taskId}
${ms(l.startUs)} – ${ms(l.endUs)} ms（跨度 ${ms(l.spanUs)} ms）
${l.blocks.n} 块 / 占用 ${l.coresUsed} 个核（共 ${nCores}）/ ${l.waves} 波
算 ${ms(l.computeUs)} ms · setup ${ms(l.setupUs)} ms · setup/compute ${(l.setupUs / (l.computeUs || 1) * 100).toFixed(1)}% · 尾块核时上界 ${ms(l.tailWasteUs)} ms`;
        g.append(ttl); svg.append(g);
      });
      y0 = top + depth * ROW;
    }
  } else {
    // ---- full: one row per physical core, blocks as flat texture ----
    const show = R.launches.flatMap((l) => (l.blocks.items || []).map((b) => ({ ...b, launch: l })))
      .filter((b) => keep(b.launch.id));
    const chainIds = singleSelected == null ? null : new Set(singleChains[singleSelected]);
    const selectedRows = new Set(show.filter(b=>(b.launch.id===me&&(!qkInline||b.core===qkInline.core)) || chainIds?.has(String(b.launch.taskId))).map(b=>b.core));

    coreRows.forEach((c, i) => {
      const y = coreY(i);
      if (i === 0 || coreRows[i - 1].ct !== c.ct) {
        const headerY = i === 0 ? laneTop : coreY(aicCoreCount) - CORE_GROUP_H;
        drawCoreGroup(c.ct, headerY);
      }
      if (laneExpanded || c.id % 4 === 0 || selectedRows.has(c.id)) txt({ x: LEFT - 10, y: y + coreHeight(i) / 2 + 4,
        fill: selectedRows.has(c.id) ? C.sel : "#999999", "font-family": "var(--mono)", "font-size": 12, "text-anchor": "end" }, c.id);
    });
    show.forEach((b) => {
      const t0 = Math.max(viewStart, b.startUs), t1 = Math.min(viewEnd, b.endUs);
      if (t1 <= t0) return;
      const row = coreRows.findIndex((c) => c.id === b.core);
      if (row < 0) return;
      const x = xOf(t0), w = Math.max(.4, (t1 - t0) / viewWin * innerW);
      const isLongQk = b.launch.leaf==='qk_pv_aic' && b.core===qkHero.core;
      const showChainPhases = !!chainIds?.has(String(b.launch.taskId));
      const barH = showChainPhases ? Math.max(3,Math.min(8,coreHeight(row)-2)) : isLongQk ? Math.max(5,Math.min(22,coreHeight(row)-4)) : laneExpanded ? 16 : 2.6;
      const rowY = coreY(row), hitW = Math.max(3, w), y = rowY + (coreHeight(row) - barH) / 2;
      const isSel = b.launch.id === me && (!qkInline || b.core===qkInline.core), isCand = cand.has(b.launch.id);
      const showComposition = laneComposition && (compositionIds ? compositionIds.has(b.launch.id) : me != null && (b.launch.id === me || String(b.launch.taskId) === String(R.launches.find(t=>t.id===me)?.taskId)));
      const g = hit(b.launch.id, `${b.launch.leaf} on ${b.launch.ct} physical core ${b.core}, ${b.startUs} to ${b.endUs} microseconds`);
      g.setAttribute('data-core',b.core);
      if(window.QK_RESIDENCY.isTarget(b.launch))g.setAttribute('aria-expanded',String(qkInline?.id===b.launch.id&&qkInline?.core===b.core));
      if(isLongQk){g.classList.add('qk-long-block');g.setAttribute('data-qk-long','true');}
      if (showChainPhases) {
        g.append(el('rect',{class:'single-phase-frame',x,y,width:w,height:barH,rx:1,'pointer-events':'none'}));
        const colors = {setup:'#d6a75a',compute:'#63e6b3',other:'#777'};
        for (const phase of window.SingleDependency.blockPhases(b, viewStart, viewEnd)) {
          g.append(el('rect',{class:'single-phase-'+phase.kind,x:xOf(phase.start),y,width:Math.max(0,(phase.end-phase.start)/viewWin*innerW),height:barH,fill:colors[phase.kind],'pointer-events':'none'}));
        }
      } else if (showComposition) {
        const slot = Math.max(0, b.slotUs ?? (b.endUs - b.startUs));
        const setup = Math.max(0, b.setupUs || 0), compute = Math.max(0, b.computeUs || 0);
        const wait = Math.max(0, slot - setup - compute);
        const scale = Math.max(1e-9, setup + compute + wait);
        const parts = [
          { value: setup, fill: "#9a7639" },
          { value: compute, fill: "#dfbd69" },
          { value: wait, fill: "#f0dfb2" },
        ];
        let sx = x;
        parts.forEach((part, index) => {
          const sw = index === parts.length - 1 ? Math.max(0, x + w - sx) : w * part.value / scale;
          if (sw > 0) g.append(el("rect", { x: sx, y, width: sw, height: barH,
            fill: part.fill, opacity: .96, "pointer-events": "none" }));
          sx += sw;
        });
        if (isSel || isCand) g.append(el("rect", { x, y, width: w, height: barH, rx: laneExpanded ? 2 : 1,
          fill: "none", stroke: isSel ? C.sel : C.candidate, "stroke-width": 1, "pointer-events": "none" }));
      } else {
        g.append(el("rect", { x, y, width: w, height: barH, rx: laneExpanded ? 2 : 1,
          fill: isSel ? C.sel : metricColor(b.launch) || (isCand ? C.candidate : C.block),
          opacity: isSel || isCand || laneColor !== "none" ? 1 : .85 }));
      }
      g.append(el("rect", { x: x - (hitW - w) / 2, y: rowY, width: hitW, height: coreHeight(row), fill: "transparent" }));
      if(isLongQk && !showChainPhases){
        const expanded=qkInline?.id===b.launch.id&&qkInline?.core===b.core;
        const cy=rowY+coreHeight(row)/2,ink='#0b241a';
        g.setAttribute('aria-label',`核内流水 · ${(b.computeUs/1000).toFixed(3)} ms · ${expanded?'收起':'展开'}`);
        g.append(el('rect',{class:'qk-inline-entry',x,y,width:w,height:barH,rx:3,fill:expanded?'#8cefc9':'#63e6b3','pointer-events':'none'}));
        g.append(el('rect',{x,y,width:4,height:barH,rx:2,fill:'#21b781','pointer-events':'none'}));
        if(w>90){
          g.append(el('path',{d:`M ${x+8} ${cy-5} v10 M ${x+12} ${cy-3} h7 M ${x+12} ${cy+1} h10 M ${x+12} ${cy+5} h5`,fill:'none',stroke:ink,'stroke-width':1.2,'stroke-linecap':'round','pointer-events':'none'}));
          txt({x:x+28,y:cy,'dominant-baseline':'middle','font-family':'var(--font)','font-size':12,'font-weight':600,fill:ink,'pointer-events':'none'},'核内流水',g);
          const arrowX=x+84;
          g.append(el('path',{d:expanded?`M ${arrowX-3} ${cy-2} l3 3 3-3`:`M ${arrowX-2} ${cy-3} l3 3-3 3`,fill:'none',stroke:ink,'stroke-width':1.3,'stroke-linecap':'round','stroke-linejoin':'round','pointer-events':'none'}));
        }
        if(w>260){
          g.append(el('rect',{x:x+w-52,y:cy-9,width:46,height:18,rx:9,fill:'#ffffff','fill-opacity':.65,'pointer-events':'none'}));
          txt({x:x+w-29,y:cy,'text-anchor':'middle','dominant-baseline':'middle','font-family':'var(--font)','font-size':11,'font-weight':600,fill:ink,'pointer-events':'none'},expanded?'收起':'展开',g);
        }
        if(w>170)txt({x:x+w-(w>260?62:8),y:cy,'text-anchor':'end','dominant-baseline':'middle','font-family':'var(--mono)','font-size':11,fill:ink,'pointer-events':'none'},(b.computeUs/1000).toFixed(3)+' ms',g);
      }
      if (!isLongQk && isSel && !recommendedFocus && w > 64 && b === show.find(item => item.launch.id === me)) {
        const labelFontSize = showComposition ? 13 : 12;
        const room = Math.max(1, Math.floor((w - 8) / (labelFontSize * .6)));
        const label = b.launch.leaf.length > room ? b.launch.leaf.slice(0, room - 1) + "…" : b.launch.leaf;
        const gray = laneColor === "none" ? (isCand ? 168 : 86)
          : Math.round(56 + 152 * Math.max(0, Math.min(1, metricValue(b.launch) / metricCap)));
        txt({ x: x + 4, y: rowY + coreHeight(row) / 2, "dominant-baseline": "middle",
          "font-family": "var(--mono)", "font-size": labelFontSize, "font-weight": showComposition ? 600 : 400,
          fill: showComposition ? "#fffaf0" : isSel || gray > 155 ? "#111111" : "#f2f2f2",
          "paint-order": "stroke", stroke: showComposition ? "#493719" : "#111111", "stroke-width": showComposition ? 2.2 : .65,
          "pointer-events": "none" }, label, g);
      }
      const ttl = el("desc", {});
      const blockSlot = Math.max(0, b.slotUs ?? (b.endUs - b.startUs));
      const blockWait = Math.max(0, blockSlot - (b.computeUs || 0) - (b.setupUs || 0));
      ttl.textContent = `${b.launch.leaf} · ${b.launch.ct} · core ${b.core}
Task ${b.launch.taskId} · ${b.startUs.toFixed(1)}–${b.endUs.toFixed(1)} μs
${showChainPhases ? '计时分段' : '耗时构成（按比例绘制）'}：Setup ${b.setupUs.toFixed(1)} μs · 计算 ${b.computeUs.toFixed(1)} μs · 未归因 ${blockWait.toFixed(1)} μs（占用−Setup−计算残差）
Task 组 Setup 占比 ${(b.launch.setupUs / (b.launch.setupUs + b.launch.computeUs || 1) * 100).toFixed(1)}% · 尾块核时上界 ${ms(b.launch.tailWasteUs)} ms`;
      if(showChainPhases) ttl.textContent += `\n计算起点约 ${(b.endUs-b.computeUs).toFixed(1)} μs；Setup 可能包含等待依赖，不能直接等同于依赖等待。`;
      g.append(ttl); svg.append(g);
    });
  }

  if(inlineIndex>=0){
    const launch=R.launches.find(t=>t.id===qkInline.id),original=launch.blocks.items.find(b=>b.core===qkInline.core);
    const group=window.QK_RESIDENCY.renderInline(svg,{y:coreY(inlineIndex)+coreHeight(inlineIndex),height:INLINE_H,W,LEFT,xOf,viewStart,viewEnd,original,leaf:launch.leaf});
    if(inlineEvolution)queueMicrotask(()=>{if(group.isConnected)window.INLINE_PASS_TRANSFORM.mount(group,{y:coreY(inlineIndex)+coreHeight(inlineIndex),W,LEFT,first:Math.floor(inlineEvolutionState.iter/2)*2,zoomFrom:inlineZoomFrom,onBack:()=>{const scroll=$("lane-wrap").scrollTop;window.INLINE_PASS_TRANSFORM.stop();inlineEvolution=false;laneRange=inlineReturnRange;renderLane();$("lane-wrap").scrollTop=scroll;}});inlineZoomFrom=null;});
  }
  if (taskGroupLabels && !qkInline) svg.append(taskGroupLabels);
  // 4. landmark labels sit inside the lane area; their ranges are drawn beneath the blocks above.
  const textW = (str) => [...str].reduce((a, ch) => a + (ch.charCodeAt(0) > 255 ? 12 : 7.2), 0);
  let intervalLabelIndex = 0;
  marks.forEach((m) => {
    if (m.t1 < viewStart || m.t0 > viewEnd) return;
    const x0 = xOf(Math.max(viewStart, m.t0)), x1 = Math.max(x0 + 2, xOf(Math.min(viewEnd, m.t1)));
    const col = m.hot ? C.accent : "#b0b0b0";
    const g = m.id ? hit(m.id, m.label) : el("g", {});
    g.setAttribute("data-lane-annotation", "true");
    const fullLabel = `${m.label} · ${m.note}`;
    const launch = m.id ? R.launches.find((l) => l.id === m.id) : null;
    let taskAnchor = null;
    if (launch && byTask) {
      const row = pk.lane.get(launch.id);
      if (row != null) taskAnchor = { x0: xOf(launch.startUs), x1: xOf(launch.endUs), y: laneTop + GH + row * ROW + ROW / 2 };
    } else if (launch) {
      const block = (launch.blocks.items || []).slice().sort((a, b) => a.startUs - b.startUs)[0];
      if (block) {
        const row = coreRows.findIndex((core) => core.id === block.core);
        // Anchor to the launch span, not its first block: for multi-wave tasks
        // (such as rank1 kv_score_proj) the first block ends long before the
        // task, which made the label float over the task's own later blocks.
        if (row >= 0) taskAnchor = { x0: xOf(launch.startUs), x1: xOf(launch.endUs), y: coreY(row) + coreHeight(row) / 2 };
      }
    }
    const labelMax = taskAnchor ? 260 : Math.min(360, Math.max(100, x1 - x0));
    let label = taskAnchor && launch && m.label.startsWith("最长 Task")
      ? `最长 Task · ${ms(launch.spanUs)} ms`
      : m.label;
    while (label.length > 4 && textW(label) > labelMax - 12) label = `${label.slice(0, -2)}…`;
    const labelWidth = Math.min(labelMax, textW(label) + 10);
    let labelX, y;
    if (taskAnchor) {
      const afterTask = taskAnchor.x1 + 5;
      const beforeTask = taskAnchor.x0 - labelWidth - 5;
      labelX = afterTask + labelWidth <= W - RIGHT ? afterTask : beforeTask;
      labelX = Math.max(LEFT, Math.min(W - labelWidth - RIGHT, labelX));
      y = taskAnchor.y;
    } else {
      y = laneTop + 13 + intervalLabelIndex++ * 16;
      labelX = Math.max(LEFT, Math.min(W - labelWidth - RIGHT, x0 + 2));
    }
    g.append(el("rect", { x: labelX, y: y - 9, width: labelWidth, height: 20, rx: 10,
      fill: m.hot ? C.accent : "#383838", "fill-opacity": 1, stroke: "none" }));
    const t = el("text", { x: labelX + 5, y: y + 4, fill: "#fff", "font-family": "var(--mono)", "font-size": 13 });
    t.textContent = label;
    g.append(t);
    const ttl = el("desc", {}); ttl.textContent = `${m.label}\n${m.note}\n${ms(m.t0)} – ${ms(m.t1)} ms`;
    g.append(ttl); svg.append(g);
  });

  let laneHoverEvent = null, hoverFrame = 0, hoverPointer = null;
  svg.onpointermove = e => {
    const event = e.target.closest?.('.task-event');
    if (event === laneHoverEvent) return;
    laneHoverEvent = event;
    hoverPointer = {clientX:e.clientX,clientY:e.clientY};
    cancelAnimationFrame(hoverFrame);
    hoverFrame=requestAnimationFrame(()=>{if(event?.isConnected || !event)drawLaneRelations(event,hoverPointer);});
  };
  svg.onpointerleave = () => { cancelAnimationFrame(hoverFrame); laneHoverEvent = null; drawLaneRelations(); };
  svg.onfocusin = e => drawLaneRelations(e.target.closest?.('.task-event'));
  svg.onfocusout = () => drawLaneRelations();
  const laneAction=e=>{
    if(e.target.closest?.('[aria-disabled="true"]'))return;
    if(e.target.closest?.('[data-qk-collapse]')){closeQkInline();return;}
    if(e.target.closest?.('[data-qk-inline-pass]')){openQkInlinePass();return;}
    const event=e.target.closest?.('[data-qk-inline-iter]');
    if(event){window.QK_RESIDENCY.chooseInline(event.dataset.qkInlineEvent,event.dataset.qkInlineIter);return;}
    const tag=e.target.closest?.('[data-result-tag]');if(tag){focusRecommendation(tag.dataset.resultTag);return;}
    const g=e.target.closest?.('.task-event');if(g)select(g.dataset.id,g.hasAttribute('data-core')?Number(g.dataset.core):null);
  };
  svg.onclick=laneAction;
  svg.onkeydown=e=>{if(['Enter',' '].includes(e.key)&&e.target.closest?.('.task-event,[data-result-tag],.qk-pipe-event,.qk-inline-control')){e.preventDefault();laneAction(e);}};

  $("lane-rows").hidden = byTask;
  $("lane-rows").nextElementSibling.hidden = byTask;
  $("lane-rows").setAttribute("aria-pressed", String(laneExpanded));
  $("lane-rows").setAttribute("aria-label", laneExpanded ? "紧凑行" : "展开行");
  $("lane-rows").dataset.tooltip = laneExpanded ? "紧凑行" : "展开行";
  const openMenus = [...document.querySelectorAll("#lane-ovl details[open],#lane-zoom details[open]")].map(d=>d.dataset.menu);
  $("lane-ovl").innerHTML =
    `<div class="bar-group"><details class="bar-menu" data-menu="view"><summary class="ctl view-selector" aria-label="泳道布局">${byTask?'按 Task':'按物理核'}</summary><div class="menu-panel view-menu">${[['task','按 Task'],['core','按物理核']].map(([value,label])=>`<button class="ctl choice-item" data-view="${value}" role="radio" aria-checked="${laneView===value}">${label}</button>`).join('')}</div></details></div><span class="analysis-group-label">分析</span>`
    + `<div class="bar-group"><details class="bar-menu" data-menu="display"><summary class="ctl" aria-label="显示设置" data-tooltip="显示设置"><svg class="control-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3" fill="var(--bg)"/><circle cx="15" cy="17" r="3" fill="var(--bg)"/></svg></summary><div class="menu-panel">`
    + `<strong>显示模块</strong>`
    + [["ribbon","并行宽度"]]
      .map(([k,label])=>`<button class="ctl" data-ovl="${k}" aria-label="${label}" aria-pressed="${k==='composition'?laneComposition:!!ovl[k]}">${label}</button>`).join('')
    + '<div class="menu-divider"></div><strong>着色</strong>'
    + [['none','默认着色'],['setup','Setup 占比'],['tail','尾块浪费']].map(([v,l])=>`<button class="ctl choice-item" data-color="${v}" role="radio" aria-checked="${laneColor===v}">${l}</button>`).join('') + '</div></details></div>'
    + `<div class="bar-group"><details class="bar-menu" data-menu="path"><summary class="ctl mode-pill${pathAnalysisActive ? ' on' : ''}" data-path-mode data-tooltip="沿关键路径定位等待与串行瓶颈。" aria-pressed="${pathAnalysisActive}" aria-label="路径分析">路径</summary><div class="menu-panel results-menu path-menu">${[["bands","低并行区"],["marks","地标"]].map(([k,label])=>`<button class="ctl" data-ovl="${k}" aria-pressed="${!!ovl[k]}">${label}</button>`).join('')}<div class="menu-divider"></div><strong>路径任务 · ${R.criticalPath.length}</strong>${(()=>{const rows=R.criticalPath.map((p,i)=>{const matches=recommendTaskGroups().groups.filter(g=>g.tasks.some(t=>String(t.taskId)===String(p.taskId)));return {problem:matches.length>0,html:`<button class="ctl result-item" data-path-task="${esc(p.taskId)}" aria-pressed="${p.ids?.includes(me)||String(R.launches.find(t=>t.id===me)?.taskId)===String(p.taskId)}"><span class="result-name">${TaskSemanticIcons.task(p.name,matches.length?taskLayerColor(matches[0].primaryMode):null)}<span>#${i+1} · ${esc(p.name)}</span></span><small>${ms(p.spanUs)} ms · ${matches.length?matches.map(g=>esc(taskFeatureName(g.primaryMode))).join(' / '):/(^|_)wait($|_)/.test(p.name)?'等待任务':'无已标记特征'}</small></button>`};});const quiet=rows.filter(r=>!r.problem);return rows.filter(r=>r.problem).map(r=>r.html).join('')+(quiet.length?`<details class="path-quiet"><summary>未标记问题 · ${quiet.length} 项</summary>${quiet.map(r=>r.html).join('')}</details>`:'');})()}</div></details></div>`
    + (`<div class="bar-group"><details class="bar-menu" data-menu="filter"><summary class="ctl mode-pill${!resultsActive && !pathAnalysisActive && !document.body.classList.contains('compile-analysis-mode') ? " on" : ""}" data-filter-mode data-tooltip="按性能特征查找同类问题。" aria-pressed="${!resultsActive && !pathAnalysisActive && !document.body.classList.contains('compile-analysis-mode')}" aria-label="特征筛选">特征</summary><div class="menu-panel"><strong>任务特征</strong>` + TASK_LAYERS.map(([v,l])=>`<button class="ctl choice-item" data-task-layer="${v}" role="radio" aria-checked="${taskLayer===v}"><span>${TaskSemanticIcons.feature(v, v === "none" ? null : v === "recommended" ? "conic-gradient(from 0deg," + ["tail", "setup", "parallel", "bubble", "underfill", "fragmented", "imbalance", "tail"].map(key => taskLayerColor(key)).join(",") + ")" : taskLayerColor(v))}${l}</span></button>`).join('') + `<div class="menu-divider"></div><button class="ctl" data-ovl="only" aria-pressed="${!laneAll}">仅显示候选</button></div></details></div>`)
    + `<div class="bar-group">${window.CompileAnalysis?.menu().replace('>编译分析</summary>',' aria-label="编译分析">编译</summary>') || '<button class="ctl" data-compile-tab>编译</button>'}</div>`
    + `<div class="bar-group"><details class="bar-menu" data-menu="results"><summary class="ctl mode-pill${resultsActive ? " on" : ""}" aria-pressed="${resultsActive}" data-results data-tooltip="优先排查推荐任务，查看优化证据。" aria-label="优化候选">优化</summary><div class="menu-panel results-menu"><strong>优化候选</strong>${recommendTaskGroups().groups.map(group=>`<button class="ctl result-item" data-result-choice="${esc(group.key)}" aria-pressed="${recommendedFocus===group.key}"><span class="result-name">${TaskSemanticIcons.task(group.kernel,taskLayerColor(group.primaryMode))}${esc(group.kernel)}</span><small>${esc(group.evidence[0].reason)}</small></button>`).join('')}</div></details></div>`
    + '<div class="bar-group"><details class="bar-menu legend-menu" data-menu="legend"><summary class="ctl" aria-label="图例与交互说明"><svg class="control-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 11v6M12 7v.1"/></svg></summary><div class="menu-panel"><strong>图例与交互</strong><div class="lgnd" id="lane-lgnd"></div></div></details></div>';
  $("lane-zoom").querySelectorAll('[data-menu="display"],[data-menu="legend"]').forEach(n=>n.parentElement.remove());
  for(const key of ['display','legend']){
    const menu=$("lane-ovl").querySelector(`[data-menu="${key}"]`);if(menu)$("lane-zoom").append(menu.parentElement);
  }
  openMenus.forEach(k=>{const d=document.querySelector(`[data-menu="${k}"]`);if(d)d.open=true;});

  const colorLegend = activeLayer !== "none"
    ? ""
    : laneColor === "none"
    ? `<span><i style="background:${C.candidate}"></i>默认任务</span>`
    : `<span><i style="width:36px;height:8px;background:linear-gradient(90deg,#383838,#d0d0d0)"></i>${laneColor === "setup" ? "setup / compute" : "尾块核时上界"} · 0 → ${laneColor === "setup" ? `${metricCap.toFixed(0)}%` : `${metricCap.toFixed(2)} ms`}+（P90 饱和）</span>`;
  const layerHint = ({
    recommended: "候选任务组 · 悬停查看直接依赖",
    tail: "组包络右缘显示各核收尾与拖尾形态",
    parallel: "内包络 = 组的占核范围 · 外虚框 = 该类全部核",
    imbalance: "同组收尾参差 · 包络右缘加重显示",
    underfill: "内包络显示末端收缩 · 外虚框表示可用核范围",
    fragmented: "邻近短 Task 聚成点线簇 · 大片空隙保留",
    setup: "半透明包络表示高 Setup 的 Task 组范围",
    bubble: "虚线包络表示相关 Task 组的依赖间隔",
  })[activeLayer] || "";
  const taskLayerLegend = !byTask && activeLayer !== "none"
    ? '<span><i style="width:24px;height:10px;border:1px solid ' + taskProfileColor
      + ';background:' + taskProfileColor + '33;border-radius:3px"></i>' + layerHint + '</span>'
    : "";
  $("lane-lgnd").innerHTML = [
    `<span><i style="background:${C.accent}"></i>关键路径：单块任务 · 纯等待</span><span><i style="background:${C.AIC}"></i>关键路径：落到核上的计算</span>`,
    `<span><i style="background:${C.block}"></i>${byTask ? "一次提交" : "Task block（底层）"}</span>`,
    colorLegend,
    `<span><i style="background:${C.sel}"></i>当前选中</span>`,
    taskLayerLegend,
    ovl.ribbon ? `<span><i style="width:16px;height:2px;background:#c4c4c4"></i>并行宽度低于 25% 参考线</span>` : "",
    ovl.bands && pathAnalysisActive ? `<span><i style="background:${C.warn}"></i>低并行（≤2 核）</span><span><i style="background:${C.accent}"></i>真空窗（0 核）</span>` : "",
    laneComposition ? `<span><i style="background:#9a7639"></i>Setup</span><span><i style="background:#dfbd69"></i>计算</span><span><i style="background:#f0dfb2"></i>槽内等待</span><span data-tooltip="同一黄色系以明度区分 Setup、计算和槽内等待；仅按耗时比例分段，不代表真实阶段位置">同色系明度区分 · 按耗时比例分段 · 悬停查看数值</span>` : "",
    singleSelected != null && !byTask ? `<span><i style="background:#d6a75a"></i>Setup（可能包含等待）</span><span><i style="background:#63e6b3"></i>实际计算</span><span><i style="background:#777"></i>未归因时间</span>` : "",
    byTask
      ? `<span>条宽 = Task 跨度 · <b style="color:var(--text-2)">条高统一 · 占核数见任务详情</b> · 同轨的 Task 时间不重叠</span>`
      : `<span>每行 = 一个物理核 · 横轴 = 设备时间 · 悬停看耗时分解</span>`,
  ].join("");
  syncLaneNavigator();
  prepareHoverTips();
  resultHoverKey=null;resultHoverNodes=new Map();
  svg.querySelectorAll('[data-result-region],[data-result-tag]').forEach(node=>{
    const key=node.dataset.resultRegion||node.dataset.resultTag;
    if(!resultHoverNodes.has(key))resultHoverNodes.set(key,[]);
    resultHoverNodes.get(key).push(node);
  });
  indexLaneRelations();
  applySingleChain();
  featurePreviewCache=new Map(); featurePreviewMode=null;
  drawLaneRelations();
}

let laneNavigator=null, navigatorRank=null;
function setLaneRange(a,b){
  const full=R.kpi.windowUs,span=Math.min(full,Math.max(full/256,b-a));
  const start=Math.max(0,Math.min(full-span,a));
  laneRange=span>=full-1e-6?null:[start,start+span];renderLane();
}
function syncLaneNavigator(){
  const root=$("lane-navigator"),full=R.kpi.windowUs;
  if(navigatorRank!==R){
    laneNavigator?.destroy();root.replaceChildren();navigatorRank=R;
    const overview=el('svg',{viewBox:'0 0 400 32',preserveAspectRatio:'none','aria-hidden':'true'});
    const segs=concStats().segs;
    for(let i=0;i<160;i++){
      const a=i/160*full,b=(i+1)/160*full;
      const active=Math.max(0,...segs.filter(seg=>seg[0]<b&&seg[1]>a).map(seg=>seg[2]));
      const h=2+active/R.kpi.totalCores*26;
      overview.append(el('rect',{x:i*2.5,y:30-h,width:1.8,height:h,fill:'#777'}));
    }
    root.append(overview);
    laneNavigator=SequenceNavigation.mount(root,{items:[],variant:'time',full:[0,full],onRange:([a,b])=>setLaneRange(a,b)});
    root.querySelector('.sequence-window').setAttribute('aria-label','可见时间窗口：拖动平移，拖动两侧缩放；方向键平移，加减键缩放');
    root.onclick=e=>{
      if(e.target.closest('.sequence-window'))return;
      const rect=root.getBoundingClientRect(),center=(e.clientX-rect.left)/rect.width*R.kpi.windowUs;
      const range=laneRange||[0,R.kpi.windowUs],span=range[1]-range[0];setLaneRange(center-span/2,center+span/2);
    };
  }
  const range=laneRange||[0,full];laneNavigator.update({range});
  root.querySelector('.sequence-window').setAttribute('aria-description',ms(range[0])+' – '+ms(range[1])+' ms');
}

// Same interaction as CSA: hover takes precedence over pinned selection;
// only direct dependency edges from the current rank are shown.
let laneRelationIndex = null;
let resultHoverNodes = new Map(), resultHoverKey = null;
function applySingleChain() {
  const svg = $("lane"), chain = singleSelected == null ? null : singleChains[singleSelected], ids = chain ? new Set(chain) : null;
  svg.classList.toggle('single-chain-active', !!ids);
  if (!laneRelationIndex) return;
  for (const {element, task} of laneRelationIndex.byElement.values()) {
    element.classList.toggle('single-hit', !!ids && ids.has(String(task.taskId)));
    element.classList.toggle('single-muted', !!ids && !ids.has(String(task.taskId)));
  }
  if (!chain) return;
  const width = svg.viewBox.baseVal.width, left = laneLeft(), right = width - 12;
  const bounds = chain.map(id => {
    const entries = laneRelationIndex.byTask.get(id) || [];
    if (!entries.length) return null;
    return {x0:Math.min(...entries.map(e=>e.box.x)), x1:Math.max(...entries.map(e=>e.box.x+e.box.w)),
      y0:Math.min(...entries.map(e=>e.box.cy-e.box.h/2)), y1:Math.max(...entries.map(e=>e.box.cy+e.box.h/2))};
  });
  const group = el('g', {class:'single-chain-annotation', 'pointer-events':'none', 'aria-hidden':'true'});
  const defs = el('defs', {}), marker = el('marker', {id:'single-chain-arrow', viewBox:'0 0 10 10', refX:8, refY:5, markerWidth:7, markerHeight:7, orient:'auto-start-reverse'});
  marker.append(el('path', {d:'M 0 0 L 10 5 L 0 10 z', fill:'#8cefc9'})); defs.append(marker); group.append(defs);
  for(let i=0;i<bounds.length-1;i++){
    const a=bounds[i],b=bounds[i+1]; if(!a||!b)continue;
    const x1=a.x1,y1=(a.y0+a.y1)/2,x2=b.x0,y2=(b.y0+b.y1)/2,dx=Math.max(16,Math.abs(x2-x1)*.45);
    const d=`M ${x1} ${y1} C ${x1+dx} ${y1}, ${x2-dx} ${y2}, ${x2} ${y2}`;
    group.append(el('path',{d,fill:'none',stroke:'#111','stroke-width':5,'stroke-opacity':.8}));
    group.append(el('path',{d,fill:'none',stroke:'#8cefc9','stroke-width':1.5,'marker-end':'url(#single-chain-arrow)'}));
  }
  const labels=[];
  bounds.forEach((box,i) => {
    if (!box) return;
    const x=Math.max(left,box.x0-3), end=Math.min(right,Math.max(box.x1+3,x+8)), y=Math.max(0,box.y0-3);
    group.append(el('rect', {class:'single-task-boundary',x,y,width:Math.max(1,end-x),height:Math.max(8,box.y1-y+3),rx:3,fill:'#63e6b3','fill-opacity':.045,stroke:'#63e6b3','stroke-opacity':.9,'stroke-width':1,'stroke-dasharray':'4 3'}));
    const name=singleTaskName(chain[i]), text=name.length>24?name.slice(0,23)+'…':name;
    const w=Math.min(right-left,Math.max(60,32+text.length*7)), lx=Math.max(left,Math.min(right-w,x));
    let ly=Math.max(0,y-24);
    for(let step=0;step<chain.length;step++){
      if(!labels.some(p=>lx<p.x+p.w && lx+w>p.x && ly<p.y+22 && ly+22>p.y))break;
      ly=Math.min(svg.viewBox.baseVal.height-22,ly+24);
    }
    labels.push({x:lx,y:ly,w});
    group.append(el('rect',{x:lx,y:ly,width:w,height:22,rx:4,fill:'#14362a',stroke:'#63e6b3'}));
    group.append(el('circle',{cx:lx+12,cy:ly+11,r:8,fill:'#63e6b3'}));
    const number=el('text',{x:lx+12,y:ly+14,'text-anchor':'middle',fill:'#10251b','font-family':'var(--font)','font-size':10,'font-weight':600});number.textContent=String(i+1);group.append(number);
    const label=el('text',{class:'single-task-label',x:lx+25,y:ly+15,fill:'#e0fff0','font-family':'var(--font)','font-size':11});label.textContent=text;group.append(label);
  });
  svg.append(group);
}
function singleTaskName(id) { return R.taskNames?.[id] || R.launches.find(t => String(t.taskId) === id)?.leaf || ('Task ' + id); }
function syncSingleScrollSpace() {
  const height = singleSelected == null ? 0 : Math.ceil($('lane-wrap').clientHeight / 2);
  $('single-scroll-before').style.height = height + 'px';
  $('single-scroll-after').style.height = height + 'px';
}
function centerSingleChain() {
  if (singleSelected == null || !laneRelationIndex) return;
  const entries = singleChains[singleSelected].flatMap(id => laneRelationIndex.byTask.get(id) || []);
  if (!entries.length) return;
  const wrap = $('lane-wrap'), view = wrap.getBoundingClientRect();
  const stickyHeight = wrap.querySelector('.lane-axis-sticky').getBoundingClientRect().height;
  const boxes = entries.map(entry => entry.element.getBoundingClientRect());
  const center = (Math.min(...boxes.map(box => box.top)) + Math.max(...boxes.map(box => box.bottom))) / 2;
  const availableTop = view.top + wrap.clientTop + Math.min(stickyHeight, wrap.clientHeight);
  const availableBottom = view.top + wrap.clientTop + wrap.clientHeight;
  const target = wrap.scrollTop + center - (availableTop + availableBottom) / 2;
  wrap.scrollTop = Math.max(0, Math.min(wrap.scrollHeight - wrap.clientHeight, target));
}
function updateSingleGrip() {
  const grip = $('single-panel-grip'), panel = $('single-panel');
  grip.setAttribute('aria-valuemin', '300');
  grip.setAttribute('aria-valuemax', String(Math.max(300, Math.min(700, window.innerWidth - 360))));
  grip.setAttribute('aria-valuenow', String(Math.round(panel.getBoundingClientRect().width)));
}
function renderSinglePanel() {
  const panel = $('single-panel');
  document.body.classList.toggle('single-panel-open', singlePanelOpen);
  panel.hidden = !singlePanelOpen;
  $('single-panel-grip').hidden = !singlePanelOpen;
  if (singlePanelOpen) updateSingleGrip();
  if (!singlePanelOpen) return;
  const label = singleTaskName;
  const rows = singleChains.map((chain, i) => {
    const steps = chain.map((id, step) => {
      const task = R.launches.find(t => String(t.taskId) === id);
      return `<span class="single-path-step" data-tooltip="Task ID ${esc(id)}"><span class="single-path-number" aria-hidden="true">${step + 1}</span><span class="single-path-name">${esc(label(id))}</span><span class="single-path-id">${esc(task?.tag || id)}</span></span>`;
    }).join('');
    const description = chain.map(id => `${label(id)}，Task ID ${id}`).join(' → ');
    return `<tr class="${singleSelected === i ? 'single-selected' : ''}"><td>${String(i + 1).padStart(2,'0')}</td><td><span class="single-count">${chain.length}</span></td><td><button type="button" class="single-path" data-single-chain="${i}" aria-pressed="${singleSelected === i}" aria-label="任务链 ${i + 1}：${esc(description)}">${steps}</button></td></tr>`;
  }).join('');
  panel.innerHTML = `<header><h2>连续单依赖分析</h2><button class="single-close" data-single-close aria-label="关闭连续单依赖分析并清除高亮">×</button></header>${singleSelected != null ? '<div class="single-phase-legend"><span><i style="background:#d6a75a"></i>Setup</span><span><i style="background:#63e6b3"></i>实际计算</span><span><i style="background:#777"></i>未归因时间</span><small>按每个 block 的计时分段；Setup 可能包含依赖等待和本地准备，不能仅凭颜色判断等待原因。</small></div>' : ''}${rows ? '<table><colgroup><col class="single-col-number"><col class="single-col-count"><col></colgroup><thead><tr><th>序号</th><th>任务数</th><th>任务路径</th></tr></thead><tbody>' + rows + '</tbody></table>' : '<p>当前 Rank 没有满足条件的任务链。</p>'}`;
}
function highlightResult(key) {
  if(resultHoverKey===key)return;
  resultHoverKey=key;
  for(const [group,nodes] of resultHoverNodes) for(const node of nodes){
    node.classList.toggle('result-hover',group===key);
    node.classList.toggle('result-muted',!!key && group!==key);
  }
}

let featurePreviewCache=new Map(), featurePreviewMode=null;
function previewTaskFeature(mode){
  if(featurePreviewMode===mode)return;
  featurePreviewMode=mode;
  const svg=$("lane");svg.querySelector('#feature-menu-preview')?.remove();
  if(!mode||mode==='none'||!laneRelationIndex)return;
  if(!featurePreviewCache.has(mode)){
    const hits=analyzeTaskLayer(mode).hits;
    const d=[];
    for(const entry of laneRelationIndex.byElement.values())if(hits.has(entry.task.id)){
      const b=entry.box;d.push(`M${b.x} ${b.cy}h${Math.max(1,b.w)}`);
    }
    featurePreviewCache.set(mode,d.join(' '));
  }
  const preview=el('path',{id:'feature-menu-preview',d:featurePreviewCache.get(mode),fill:'none',stroke:taskLayerColor(mode),'stroke-width':3,'stroke-linecap':'round','pointer-events':'none'});
  svg.append(preview);
}

function indexLaneRelations() {
  $("lane").classList.remove("has-relation");
  const byTask = new Map(), byElement = new Map(), edges = new Map();
  const launches = new Map(R.launches.map(l => [l.id,l]));
  // Read geometry once per render, before any hover styling is written.
  for (const element of $("lane").querySelectorAll('.task-event')) {
    const task = launches.get(element.getAttribute('data-id')); if (!task) continue;
    const bounds = (element.querySelector('rect') || element).getBBox();
    const item = { element, task, box: { x:bounds.x, w:bounds.width, h:bounds.height, cy:bounds.y+bounds.height/2 } };
    const key=String(task.taskId);
    if(!byTask.has(key)) byTask.set(key,[]);
    byTask.get(key).push(item); byElement.set(element,item);
  }
  const seen = new Set();
  for(const edge of R.edges){
    const pred=String(edge.pred), succ=String(edge.succ), key=pred+'>'+succ;
    if(seen.has(key))continue; seen.add(key);
    for(const id of new Set([pred,succ])){
      if(!edges.has(id))edges.set(id,[]);
      edges.get(id).push({pred,succ});
    }
  }
  const paths = new Map();
  for (const [id, entries] of byTask) {
    paths.set(id, entries.map(({box:b})=>`M ${b.x} ${b.cy} h ${Math.max(1,b.w)}`).join(' '));
  }
  const overlay=el('g',{id:'lane-relations','pointer-events':'none','aria-label':'当前任务与直接依赖'});
  const svg=$("lane"),foreground=svg.querySelector('[data-lane-labels]')||svg.querySelector('[data-lane-annotation]');
  svg.insertBefore(overlay,foreground);
  // Keep interactive entry bars and task labels above hover/dependency strokes.
  for(const entry of svg.querySelectorAll('.qk-long-block'))svg.insertBefore(entry,foreground);
  laneRelationIndex={byTask,byElement,edges,paths,overlay,last:null};
}
function drawLaneRelations(hovered = null, pointer = null) {
  const index=laneRelationIndex; if(!index)return;
  const svg=$("lane"), tip=$("lane-hover-tip");
  const item=index.byElement.get(hovered) || [...(index.byTask.get(String(R.launches.find(l=>l.id===me)?.taskId)) || [])].find(i=>i.task.id===me);
  const identity=(item ? String(item.task.taskId) : '')+':'+(hovered?'hover':'selected')+':'+(me||'');
  const pathId=hovered&&item?String(item.task.taskId):null;
  for(const node of document.querySelectorAll('#path-analysis-lane .cpi-drawer [data-task]'))node.classList.toggle('is-linked-hover',node.dataset.task===pathId);
  for(const node of $("cp").querySelectorAll('.cp-seg'))node.classList.toggle('is-hover',node.dataset.t===pathId);
  if(index.last === identity){
    if(pointer && !tip.hidden){tip.style.left=Math.max(8,Math.min(innerWidth-310,pointer.clientX+16))+'px';tip.style.top=Math.max(8,Math.min(innerHeight-88,pointer.clientY+16))+'px';}
    return;
  }
  index.last=identity; tip.hidden=true;
  const overlay=index.overlay;
  overlay.replaceChildren();
  if(qkInline)return;
  if(!item)return;
  const task=item.task, taskId=String(task.taskId), edges=index.edges.get(taskId)||[];
  const related=new Set(edges.flatMap(e=>[e.pred,e.succ]));
  related.delete(taskId);
  // One batched path per task, no mutation/filter on thousands of event nodes.
  for(const id of related){
    const d=index.paths.get(id);if(d)overlay.append(el('path',{d,fill:'none',stroke:'#aaa','stroke-opacity':.65,'stroke-width':1.4}));
  }
  overlay.append(el('path',{d:index.paths.get(taskId)||'',fill:'none',stroke:'#dedede','stroke-opacity':.9,'stroke-width':1.8}));
  // Dependency connections belong to selection, never to transient hover.
  const selectedTask=R.launches.find(l=>l.id===me);
  const selectedId=selectedTask?String(selectedTask.taskId):null;
  const selectedItem=(index.byTask.get(selectedId)||[]).find(i=>i.task.id===me);
  if(selectedItem){
    const fb=selectedItem.box;
    const anchor=id=>{
      if(id===selectedId)return fb;
      let best=null,distance=Infinity;
      for(const entry of index.byTask.get(id)||[]){const d=Math.abs(entry.box.cy-fb.cy);if(d<distance){best=entry.box;distance=d;}}
      return best;
    };
    for(const edge of index.edges.get(selectedId)||[]){
      const a=anchor(edge.pred),b=anchor(edge.succ);if(!a||!b)continue;
      const sx=a.x+a.w,tx=b.x,mid=(sx+tx)/2,dir=tx>=mid?1:-1;
      overlay.append(el('path',{'data-dependency-line':'true',d:`M ${sx} ${a.cy} H ${mid} V ${b.cy} H ${tx}`,fill:'none',stroke:'#808080','stroke-width':1.6,'stroke-dasharray':'0.1 5','stroke-linecap':'round'}));
      overlay.append(el('path',{d:`M ${tx-dir*5} ${b.cy-3} L ${tx} ${b.cy} L ${tx-dir*5} ${b.cy+3}`,fill:'none',stroke:'#808080','stroke-width':1.3}));
    }
  }
  if(hovered&&pointer){
    tip.textContent=task.leaf+' · '+task.ct+'\n'+ms(task.startUs)+' – '+ms(task.endUs)+' ms · '+edges.length+' 条直接依赖';
    tip.hidden=false;tip.style.left=Math.max(8,Math.min(innerWidth-310,pointer.clientX+16))+'px';tip.style.top=Math.max(8,Math.min(innerHeight-88,pointer.clientY+16))+'px';
  }
}

// ---------- block distribution ----------
function distribution() {
  const svg = $("dist"); svg.textContent = "";
  const l = R.launches.find((x) => x.id === me);
  if (!l) return;
  const b = l.blocks, durs = b.durs;
  const only1 = b.n === 1;
  $("dist-wrap").hidden = only1;
  $("dist-note").hidden = !only1;
  if (only1) $("dist-note").textContent = `单块任务，没有块间分布可比 —— 这一块本身耗时 ${b.max} us。`;
  const W = 360, H = 132, PAD = 22, TOPY = 10, BASE = H - 20;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("width", W); svg.setAttribute("height", H);
  const bw = (W - PAD) / durs.length;
  const sc = (v) => (b.max ? (v / b.max) * (BASE - TOPY) : 0);
  durs.forEach((d, i) => {
    // the tail is what the panel is about, so only the slowest blocks take the accent
    const hot = !only1 && b.max > 0 && d >= b.max * 0.98;
    svg.append(el("rect", { x: PAD + i * bw, y: BASE - sc(d), width: Math.max(0.6, bw - (bw > 3 ? 0.6 : 0)),
      height: sc(d), fill: hot ? C.accent : C.AIC, opacity: hot ? 1 : .7 }));
  });
  const y = BASE - sc(b.mean);
  svg.append(el("line", { x1: PAD, x2: W, y1: y, y2: y, stroke: C.sel, "stroke-width": .8, "stroke-dasharray": "3 3" }));
  const t = el("text", { x: 0, y: y + 4, fill: C.sel, "font-family": "var(--mono)", "font-size": 12 });
  t.textContent = "均"; svg.append(t);
  const ax = el("text", { x: PAD, y: H - 6, fill: C.axis, "font-family": "var(--mono)", "font-size": 12 });
  ax.textContent = `${durs.length} 个块，按耗时升序 · 纵轴 0–${b.max} us`;
  svg.append(ax);
  const verdict = b.spread > 2 && b.p90 / (b.p50 || 1) < 1.4 ? "个别块掉队，查那一块的数据"
    : b.spread > 1.25 ? "整体偏斜，查切分粒度" : "分布均匀，无尾块问题";
  $("dist-kv").innerHTML = `<div><dt>最慢</dt><dd>${b.max} <small>µs</small></dd></div><div><dt>P90</dt><dd>${b.p90} <small>µs</small></dd></div><div><dt>中位</dt><dd>${b.p50} <small>µs</small></dd></div><div><dt>最快</dt><dd>${b.min} <small>µs</small></dd></div><div class="metric-verdict"><dt>最慢 / 平均 ${b.spread}×</dt><dd>${verdict}</dd></div>`;
}

// ---------- selected task ----------
function detail() {
  window.dispatchEvent(new CustomEvent("compile-task-selected",{detail:R.launches.find(x=>x.id===me)}));
  const l = R.launches.find((x) => x.id === me);
  if (!l) { $("detail").innerHTML = `<dt>—</dt><dd>选一个提交</dd>`; return; }
  $("pass-analysis-open").hidden = !PASS_LABELS[l.leaf];
  const taskLabel = (id) => R.taskNames[id] || id;
  const preds = R.edges.filter((e) => e.succ === l.taskId).slice(0, 3).map((e) => taskLabel(e.pred));
  const succs = R.edges.filter((e) => e.pred === l.taskId).slice(0, 3).map((e) => taskLabel(e.succ));
  $("detail").innerHTML = [
    ["Task ID", esc(l.taskId)],
    ["执行单元", `${l.ct} · ${l.blocks.n} 块 · ${l.waves} 波`],
    ["可用核", `${l.availCores} 核`],
    ["执行跨度", `${ms(l.spanUs)} ms`],
    ["计算核时", `${ms(l.computeUs)} ms`],
    ["Setup 核时", `${ms(l.setupUs)} ms`],
    ["声明搬运量", `${mib(l.bytes)} MiB`],
    ["声明带宽", `${l.gbPerS ?? "—"} GB/s`],
    ["编译来源", l.compile.bornPassName ? `P${l.compile.bornPass} · ${esc(l.compile.bornPassName)}` : "—"],
    ["前驱", preds.length ? preds.map(esc).join("、") : "无"],
    ["后继", succs.length ? succs.map(esc).join("、") : "无"],
  ].map(([k,v])=>`<dt>${k}</dt><dd>${v}</dd>`).join("");
}


function renderEvidence() {
  const task = R.launches.find(l => l.id === me); if (!task) return;
  $("evidence-title").textContent = task.leaf + " · 执行证据";
  $("evidence-body").innerHTML = '<dl class="kv">' + [
    ['设备跨度', ms(task.startUs) + ' – ' + ms(task.endUs) + ' ms'],
    ['累计核时', '计算 ' + ms(task.computeUs) + ' ms · Setup ' + ms(task.setupUs) + ' ms'],
    ['编译来源', 'P' + task.compile.bornPass + ' ' + esc(task.compile.bornPassName || '未知')],
    ['提交方式', esc(task.compile.launchKind) + ' · ' + esc(task.compile.via || task.leaf)],
    ['数据来源', esc(R.source)]
  ].map(([key,value]) => '<dt>' + key + '</dt><dd>' + value + '</dd>').join('') + '</dl><p>选择物理核检查对应 block。槽位、计算与 Setup 来自当前运行；槽内等待由槽位减去计算和 Setup 得到，不能据此确认等待原因。</p><label class="candidate-filter">物理核<select id="evidence-core" class="ctl">' + [...new Set(task.blocks.items.map(b => b.core))].sort((a,b) => a-b).map(core => '<option>' + core + '</option>').join('') + '</select></label><div id="core-evidence"></div>';
  const update = () => {
    const core = Number($("evidence-core").value), blocks = task.blocks.items.filter(b => b.core === core);
    const start = Math.min(...blocks.map(b => b.startUs)), end = Math.max(...blocks.map(b => b.endUs)), span = Math.max(1,end-start);
    $("core-evidence").innerHTML = '<p>Core ' + core + ' · ' + blocks.length + ' blocks · ' + ms(start) + ' – ' + ms(end) + ' ms</p><svg viewBox="0 0 800 40" aria-label="选中物理核时序">' + blocks.map(b => '<rect x="' + ((b.startUs-start)/span*780+10) + '" y="10" width="' + Math.max(1,(b.endUs-b.startUs)/span*780) + '" height="20" fill="#ddd"/>').join('') + '</svg><dl class="kv"><dt>计算核时</dt><dd>' + ms(blocks.reduce((a,b) => a+b.computeUs,0)) + ' ms</dd><dt>Setup 核时</dt><dd>' + ms(blocks.reduce((a,b) => a+b.setupUs,0)) + ' ms</dd></dl>';
  }; $("evidence-core").onchange = update; update();
}

// Shared in-page tips: native HTML/SVG titles must never reach browser chrome.
function prepareHoverTips() {
  for (const description of document.querySelectorAll('svg desc')) {
    const parent=description.parentElement;
    if (!parent.dataset.tooltip) parent.dataset.tooltip=description.textContent;
  }
}
const uiTip=$("ui-hover-tip");
let uiTipTarget=null;
function hideUiTip(){
  if(uiTipTarget?.getAttribute('aria-describedby')==='ui-hover-tip')uiTipTarget.removeAttribute('aria-describedby');
  uiTipTarget=null;uiTip.hidden=true;
}
function showUiTip(target,x,y){
  if(!target || target.closest('#lane') || target.matches('details[open]>summary')){hideUiTip();return;}
  if(uiTipTarget!==target){hideUiTip();uiTipTarget=target;uiTip.textContent=target.dataset.tooltip;uiTip.hidden=false;target.setAttribute('aria-describedby','ui-hover-tip');}
  if(target.closest('.lane-toolbar-group')){
    const r=target.getBoundingClientRect();
    uiTip.style.left=Math.max(8,Math.min(innerWidth-uiTip.offsetWidth-8,r.left+(r.width-uiTip.offsetWidth)/2))+'px';
    uiTip.style.top=Math.min(innerHeight-uiTip.offsetHeight-8,r.bottom+10)+'px';
    return;
  }
  if(target.closest('#lane-zoom')){
    const r=target.getBoundingClientRect();
    uiTip.style.left=Math.max(8,Math.min(innerWidth-uiTip.offsetWidth-8,r.left+(r.width-uiTip.offsetWidth)/2))+'px';
    uiTip.style.top=Math.max(8,r.top-uiTip.offsetHeight-10)+'px';return;
  }
  uiTip.style.left=Math.max(8,Math.min(innerWidth-uiTip.offsetWidth-8,x+14))+'px';
  uiTip.style.top=Math.max(8,Math.min(innerHeight-uiTip.offsetHeight-8,y+16))+'px';
}
document.addEventListener('pointerover',e=>showUiTip(e.target.closest?.('[data-tooltip]'),e.clientX,e.clientY));
document.addEventListener('pointermove',e=>{if(uiTipTarget)showUiTip(uiTipTarget,e.clientX,e.clientY);});
document.addEventListener('pointerout',e=>{if(uiTipTarget&&!uiTipTarget.contains(e.relatedTarget))hideUiTip();});
document.addEventListener('focusin',e=>{const target=e.target.closest?.('[data-tooltip]');if(target){const r=target.getBoundingClientRect();showUiTip(target,r.left,r.bottom);}});
document.addEventListener('focusout',hideUiTip);
document.addEventListener('scroll',hideUiTip,true);
document.addEventListener('keydown',e=>{if(e.key==='Escape')hideUiTip();});
window.addEventListener('blur',hideUiTip);

// ---------- wiring ----------
function paint() {
  hideUiTip(); header(); criticalPath(); renderLane(); distribution(); detail(); prepareHoverTips();
  const selected = R.launches.find((l) => l.id === me);
  $("drawer-sub").textContent = selected
    ? `${selected.leaf} · ${selected.ct} · ${selected.blocks.n} 块 / ${selected.waves} 波`
    : "点击泳道中的任务查看耗时分布与执行信息";
}
function setDrawer(open) {
  const drawer = $("task-drawer");
  drawer.classList.toggle("open", open);
  $("analysis-panel-anchor").classList.toggle("inspect-open", open);
  if (open) { $("selection-name").textContent = R.launches.find(l => l.id === me)?.leaf || ""; }
  drawer.setAttribute("aria-hidden", String(!open));
}
function closeQkInline(){
  const previous=qkReturnView;qkInline=null;qkReturnView=null;
  if(previous){laneRange=previous.range;laneView=previous.view;me=previous.me;}
  paint();if(previous)$("lane-wrap").scrollTop=previous.scroll;
}
function select(id,core=null){
  const task=R.launches.find(l=>l.id===id);if(!task)return;
  if(window.QK_RESIDENCY.isTarget(task)){
    core=core??task.blocks.items.reduce((a,b)=>a.computeUs>b.computeUs?a:b).core;
    if(qkInline?.id===id&&qkInline.core===core){closeQkInline();return;}
    if(!qkInline)qkReturnView={range:laneRange?.slice()||null,view:laneView,scroll:$("lane-wrap").scrollTop,me};
    qkInline={id,core};me=id;laneView='core';
    window.QK_RESIDENCY.bindInline(R,task,core,open=>{renderLane();if(open)openQkInlinePass();});
    const block=task.blocks.items.find(b=>b.core===core),pad=(block.endUs-block.startUs)*.07;
    const full=R.kpi.windowUs;laneRange=[Math.max(0,block.startUs-pad),Math.min(full,block.endUs+pad)];
    paint();setDrawer(false);const row=R.cores.slice().sort((a,b)=>a.id-b.id).findIndex(c=>c.id===core);
    $("lane-wrap").scrollTop=Math.max(0,laneRowCenters[row]-60);return;
  }
  qkInline=null;qkReturnView=null;me=id;recommendedFocus=recommendTaskGroups().groups.find(g=>g.tasks.some(t=>t.id===id))?.key||null;paint();setDrawer(true);
}
function selectTask(taskId) {
  const l = R.launches.find((x) => x.taskId === taskId);
  if (!l) return;
  if(window.QK_RESIDENCY.isTarget(l)){select(l.id);return;}
  qkInline=null;qkReturnView=null;
  me = l.id;
  paint();
  setDrawer(false);
}
function setLens(id) {
  lens = id;
  const first = candidatesFor(id)[0];
  if (first) me = first.id;
  paint();
}
function loadRank(name) {
  qkInline=null;qkReturnView=null;
  setDrawer(false);
  recommendedFocus = null;
  laneRange = null;
  R = D.ranks.find((r) => r.rank === name) || D.ranks[0];
  singleChains = window.SingleDependency.findChains(R.edges, R.launches.map(task => task.taskId));
  singleSelected = null;
  singlePreviousRange = null;
  singlePreviousScroll = 0;
  renderSinglePanel();
  // waves / available cores are display-only derivations, kept out of the data file
  R.launches.forEach((l) => {
    l.availCores = l.ct === "AIC" ? R.kpi.aicCores : R.kpi.aivCores;
    l.waves = Math.ceil(l.blocks.n / l.availCores);
  });
  me = null;
  laneComposition = false;
  paint();
}

try {
  D = JSON.parse($("lane-data").textContent);
  D.ranks=D.ranks.map(rank=>window.QK_RESIDENCY.withLongBlock(rank));
} catch (e) {
  document.querySelector("main").innerHTML =
    `<section class="sec"><p>数据未内联或已损坏：${esc(e.message)}。<br/>重建：<code>node Design/device-perf-lane/scripts/build_perf_lane.mjs</code></p></section>`;
  D = null;
}
if (D) {
  const singleGrip = document.createElement('div');
  singleGrip.id = 'single-panel-grip'; singleGrip.className = 'single-panel-grip'; singleGrip.hidden = true;
  singleGrip.tabIndex = 0; singleGrip.setAttribute('role', 'separator'); singleGrip.setAttribute('aria-orientation', 'vertical');
  singleGrip.setAttribute('aria-label', '调整单依赖分析面板宽度'); singleGrip.setAttribute('aria-controls', 'single-panel');
  document.querySelector('main').append(singleGrip);
  const singlePanel = document.createElement('aside');
  singlePanel.id = 'single-panel'; singlePanel.className = 'single-panel'; singlePanel.hidden = true;
  singlePanel.setAttribute('aria-label', '连续单依赖分析'); document.querySelector('main').append(singlePanel);
  let singleResizeDrag = null, singleResizeFrame = 0;
  function setSingleWidth(width) {
    const max = Math.min(700, window.innerWidth - 360), bounded = Math.max(300, Math.min(max, width));
    document.body.style.setProperty('--single-panel-requested', bounded + 'px');
    updateSingleGrip();
    if (!singleResizeFrame) singleResizeFrame = requestAnimationFrame(() => { singleResizeFrame = 0; criticalPath(); renderLane(); });
  }
  singleGrip.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    e.preventDefault(); singleResizeDrag = {x:e.clientX, width:singlePanel.getBoundingClientRect().width};
    singleGrip.classList.add('is-dragging'); singleGrip.setPointerCapture(e.pointerId);
  });
  singleGrip.addEventListener('pointermove', e => { if (singleResizeDrag) setSingleWidth(singleResizeDrag.width + singleResizeDrag.x - e.clientX); });
  const endSingleResize = () => { singleResizeDrag = null; singleGrip.classList.remove('is-dragging'); };
  singleGrip.addEventListener('pointerup', endSingleResize); singleGrip.addEventListener('pointercancel', endSingleResize);
  singleGrip.addEventListener('lostpointercapture', endSingleResize);
  singleGrip.addEventListener('keydown', e => {
    if (!['ArrowLeft','ArrowRight'].includes(e.key)) return;
    e.preventDefault(); setSingleWidth(singlePanel.getBoundingClientRect().width + (e.key === 'ArrowLeft' ? 20 : -20));
  });
  singlePanel.addEventListener('click', e => {
    if (e.target.closest('[data-single-close]')) { const restoreScroll = singleSelected != null ? singlePreviousScroll : null; singlePanelOpen = false; if (singleSelected != null) laneRange = singlePreviousRange; singleSelected = null; singlePreviousRange = null; renderSinglePanel(); renderLane(); if(restoreScroll != null)$('lane-wrap').scrollTop=restoreScroll; return; }
    const button = e.target.closest('[data-single-chain]'); if (!button) return;
    const index = Number(button.dataset.singleChain);
    if (singleSelected == null) { singlePreviousRange = laneRange?.slice() || null; singlePreviousScroll = $('lane-wrap').scrollTop; }
    singleSelected = singleSelected === index ? null : index;
    if (singleSelected != null) {
      laneView = 'core'; laneAll = true; laneRange = window.SingleDependency.focusRange(singleChains[index], R.launches, R.kpi.windowUs); taskLayer = 'none';
      pathAnalysisActive = false; recommendedFocus = null; me = null; laneComposition = false;
      qkInline = null; qkReturnView = null; setDrawer(false);
      $('analysis-panel-anchor').classList.remove('results-open');
    } else { laneRange = singlePreviousRange; singlePreviousRange = null; }
    renderSinglePanel(); renderLane();
    if (singleSelected != null) centerSingleChain(); else $('lane-wrap').scrollTop = singlePreviousScroll;
    singlePanel.querySelector(`[data-single-chain="${index}"]`)?.focus({preventScroll:true});
  });
  $('single-analysis-button').addEventListener('click', () => {
    singlePanelOpen = !singlePanelOpen;
    renderSinglePanel(); renderLane();
  });
  $("run").textContent = `${D.run} / ${D.ranks[0].program}`;
  $("soc").textContent = `${D.soc.name} ${D.soc.aicCores}×AIC ${D.soc.aivCores}×AIV`;
  $("soc").dataset.tooltip = D.soc.source;
  $("rank").innerHTML = D.ranks.map((r) => `<option value="${esc(r.rank)}">${esc(r.program)} · ${esc(r.rank)} · ${esc(D.run)}</option>`).join("");
  $("rank").dataset.tooltip = D.run;
  $("candidate-filter").innerHTML = TASK_LAYERS.filter(([v]) => v !== "none").map(([v,label]) => `<option value="${v}">${label}</option>`).join("");
  $("candidate-filter").onchange = e => { candidateFilter = e.target.value; renderRecommendations(); };
  $("analysis-panel-anchor").append($("task-drawer"));
  $("rank").onchange = (e) => loadRank(e.target.value);
  function toggleResults(open) {
    if(open){laneView="core";laneAll=true;candidateFilter="recommended";}
    recommendedFocus=null;me=null;laneComposition=false;setDrawer(false);
    $("analysis-panel-anchor").classList.toggle("results-open",open);
    if (!open) setDrawer(false);
    renderLane();
  }
  $("pass-close").addEventListener("click", () => $("pass-dialog").close());
  $("pass-dialog").addEventListener("click", (e) => {
    const memoryButton = e.target.closest('[data-memory-buffer], [data-memory-value]');
    if (memoryButton && passMode === 'diagnostic') {
      const evidenceScroll = $("pass-evidence").scrollTop;
      if (memoryButton.dataset.memoryBuffer) { memoryBuffer = memoryButton.dataset.memoryBuffer; memoryValue = null; }
      else memoryValue = memoryButton.dataset.memoryValue;
      renderPassStep(passStepIndex);
      $("pass-evidence").scrollTop = evidenceScroll;
      const attr = memoryButton.dataset.memoryBuffer ? 'data-memory-buffer' : 'data-memory-value';
      $("pass-evidence").querySelector('[' + attr + '="' + (memoryButton.dataset.memoryBuffer || memoryValue) + '"]')?.focus();
      return;
    }
    const objectButton = e.target.closest("[data-pass-object]");
    if (objectButton) { selectPassObject(objectButton.dataset.passObject); return; }
    const snapshotButton = e.target.closest("[data-pass-snapshot]");
    if (snapshotButton && passMode === 'setup') {
      passDependencyStage = snapshotButton.dataset.passSnapshot;
      renderPassStep(passStepIndex);
      $("pass-evidence").querySelector('[data-pass-snapshot="' + passDependencyStage + '"]')?.focus();
      return;
    }
    const modeButton = e.target.closest("[data-pass-mode]");
    if (modeButton) {
      passMode = modeButton.dataset.passMode;
      renderPassStep(0);
      $("pass-branches").querySelector('[data-pass-mode="' + passMode + '"]')?.focus();
      return;
    }
    const coreButton = e.target.closest("[data-setup-core]");
    if (coreButton) {
      setupCore = Number(coreButton.dataset.setupCore);
      $("pass-evidence").querySelectorAll('[data-setup-core]').forEach(button => button.setAttribute('aria-pressed', String(Number(button.dataset.setupCore) === setupCore)));
      $("setup-detail").innerHTML = setupBlockDetail();
      return;
    }
    if (e.target.closest("[data-setup-upstream]")) {
      const upstream = R.launches.find(task => task.taskId === '8589934645' && task.ct === 'AIV');
      const current = R.launches.find(task => task.leaf === 'csa_merge_pack_publish');
      if (upstream && current) {
        recommendedFocus = null; laneComposition = false; laneAll = true;
        laneRange = [Math.max(0, upstream.startUs - 30), Math.min(R.kpi.windowUs, current.endUs + 30)];
        me = upstream.id; passReturnTask = true; paint(); setDrawer(true);
        $("pass-dialog").close();
      }
      return;
    }
    const button = e.target.closest("[data-pass-step]");
    if (button) {
      const index = Number(button.dataset.passStep);
      renderPassStep(index);
      $("pass-nav").querySelector('[data-pass-step="' + index + '"]')?.focus();
    }
  });
  $("pass-dialog").addEventListener("close",()=>{
    $("pass-dialog").classList.remove("qk-mode");
    window.QK_PASS_EVOLUTION?.stop();
    $("pass-evidence").onclick=null;$("pass-evidence").onkeydown=null;
    if(passReturnKey==='memoryreuse-depth'||passReturnKey==='qk-evolution'){
      setDrawer(!!me);$("lane-ovl").querySelector('[data-results]')?.focus({preventScroll:true});return;
    }
    setDrawer(!!me);
    if(me)$("pass-analysis-open").focus({preventScroll:true});
  });
  $("pass-dialog").addEventListener("keydown",e=>{const n=e.target.closest('[data-pass-object]');if(n && (e.key==='Enter'||e.key===' ')){e.preventDefault();selectPassObject(n.dataset.passObject);}});
  $("pass-analysis-open").onclick=()=>{if(me)openPassAnalysis('task:'+me);};
  openQkInlinePass=()=>openQkEvolution();
  $("lane-ovl").addEventListener('click',e=>{if(e.target.closest('[data-pipeline-evolution]')){document.querySelectorAll('.bar-menu[open]').forEach(n=>n.open=false);openQkEvolution();}});
  function openQkEvolution(){
    window.QK_PASS_EVOLUTION.stop();
    if(!qkInline){const task=R.launches.find(l=>l.leaf==='qk_pv_aic');if(!task)return;select(task.id,task.blocks.items[0].core);}
    inlineZoomFrom=[...document.querySelectorAll('.qk-inline-pipeline [data-event-start]')].map(n=>{const r=n.querySelector('rect');return {key:n.dataset.qkInlineEvent+'-'+n.dataset.fragment,x:+r.getAttribute('x'),y:+r.getAttribute('y')+24,w:+r.getAttribute('width')};});
    const retainedScroll=$("lane-wrap").scrollTop;
    if(!inlineEvolution)inlineReturnRange=laneRange?.slice()||null;
    inlineEvolution=true;window.INLINE_PASS_TRANSFORM.autoplay();
    const launch=R.launches.find(l=>l.id===qkInline.id),block=launch.blocks.items.find(b=>b.core===qkInline.core);
    const events=window.QK_RESIDENCY.inlineEvents(block,launch.leaf).filter(e=>Math.floor(e.iter/2)===Math.floor(inlineEvolutionState.iter/2));
    if(events.length){const lo=Math.min(...events.map(e=>e.startUs)),hi=Math.max(...events.map(e=>e.endUs)),pad=(hi-lo)*.12;laneRange=[Math.max(0,lo-pad),Math.min(R.kpi.windowUs,hi+pad)];}
    renderLane();
    $("lane-wrap").scrollTop=retainedScroll;
  }
  $("lane-ovl").addEventListener('click',e=>{
    if(e.target.closest('[data-compile-memory]'))(window.CompileDrawer ? window.CompileDrawer.open('csa_merge_pack_publish',35) : openMemoryReuseCase());
    if(e.target.closest('[data-compile-qk]'))(window.CompileDrawer ? window.CompileDrawer.open('qk_pv',19) : openQkEvolution());
  });
  const filterTarget=e=>e.target.closest?.('[data-task-layer]');
  $("lane-ovl").addEventListener('pointerover',e=>{const item=filterTarget(e);if(item)previewTaskFeature(item.dataset.taskLayer);});
  $("lane-ovl").addEventListener('pointerout',e=>{const item=filterTarget(e);if(item&&!item.contains(e.relatedTarget))previewTaskFeature(null);});
  $("lane-ovl").addEventListener('focusin',e=>{const item=filterTarget(e);if(item)previewTaskFeature(item.dataset.taskLayer);});
  $("lane-ovl").addEventListener('focusout',()=>previewTaskFeature(null));
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('[data-menu="filter"]'))previewTaskFeature(null);},true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')previewTaskFeature(null);});
  $("lane-ovl").addEventListener('pointerover',e=>{const b=e.target.closest('[data-path-task]');if(b){drawLaneRelations((laneRelationIndex?.byTask.get(b.dataset.pathTask)||[])[0]?.element);window.CriticalPathIntegration.hover(b.dataset.pathTask);}});
  $("lane-ovl").addEventListener('pointerout',e=>{const b=e.target.closest('[data-path-task]');if(b&&!b.contains(e.relatedTarget)){drawLaneRelations(null);window.CriticalPathIntegration.hover(null);}});
  const resultsHoverTarget=e=>e.target.closest?.('[data-result-choice]');
  $("lane-ovl").addEventListener('pointerover',e=>{const item=resultsHoverTarget(e);if(item)highlightResult(item.dataset.resultChoice);});
  $("lane-ovl").addEventListener('pointerout',e=>{const item=resultsHoverTarget(e);if(item&&!item.contains(e.relatedTarget))highlightResult(null);});
  $("lane-ovl").addEventListener('focusin',e=>{const item=resultsHoverTarget(e);if(item)highlightResult(item.dataset.resultChoice);});
  $("lane-ovl").addEventListener('focusout',()=>highlightResult(null));
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('[data-menu="results"]'))highlightResult(null);},true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')highlightResult(null);});
  $("results-close").onclick=()=>toggleResults(false);
  $("lane-ovl").addEventListener("click",e=>{
    if(e.target.closest('[data-path-mode]')){if(pathAnalysisActive)return;e.preventDefault();pathAnalysisActive=true;toggleResults(false);renderLane();$("lane-ovl").querySelector('[data-menu="path"]').open=true;return;}
    const pathTask=e.target.closest('[data-path-task]');if(pathTask){window.CriticalPathIntegration.choose(pathTask.dataset.pathTask);$("lane-ovl").querySelector('[data-menu="path"]').open=false;return;}
    if(e.target.closest('[data-filter-mode]')&&pathAnalysisActive){e.preventDefault();pathAnalysisActive=false;renderLane();$("lane-ovl").querySelector('[data-menu="filter"]').open=true;return;}
    if(e.target.closest('[data-filter-mode],[data-results]'))pathAnalysisActive=false;
    if(e.target.closest("[data-results]")){
      if(!$("analysis-panel-anchor").classList.contains("results-open")){e.preventDefault();toggleResults(true);$("lane-ovl").querySelector('[data-menu="results"]').open=true;}
      return;
    }
    const result=e.target.closest("[data-result-choice]");
    if(result){focusRecommendation(result.dataset.resultChoice);$("lane-ovl").querySelector('[data-menu="results"]').open=false;return;}
    if(e.target.closest("[data-filter-mode]") && $("analysis-panel-anchor").classList.contains("results-open")){
      e.preventDefault();toggleResults(false);
      $("lane-ovl").querySelector('[data-menu="filter"]').open=true;
    }});
  document.addEventListener("keydown",e=>{if(e.key==="Escape" && !$("pass-dialog").open && $("analysis-panel-anchor").classList.contains("results-open"))toggleResults(false);});
  $("recommendations").addEventListener("click", (e) => {
    const button = e.target.closest("[data-recommendation]");
    if (button) focusRecommendation(button.dataset.recommendation);
  });
  const statsHeader=$("run-header"), statsToggle=$("stats-toggle");
  let statsDismissed=false;
  const statsVisible=()=>['stats-initial','stats-pinned','stats-open'].some(c=>statsHeader.classList.contains(c));
  const syncStatsToggle=()=>{const open=statsVisible();statsToggle.setAttribute('aria-expanded',String(open));statsToggle.setAttribute('aria-label',open?'收起性能统计':'展开性能统计');};
  const closeStats=()=>{statsDismissed=true;statsHeader.classList.remove('stats-initial','stats-pinned','stats-open');syncStatsToggle();};
  statsToggle.onclick=()=>{if(statsVisible())closeStats();else{statsDismissed=false;statsHeader.classList.add('stats-pinned');syncStatsToggle();}};
  $("stats-close").onclick=()=>{closeStats();statsToggle.focus({preventScroll:true});};
  statsToggle.addEventListener('pointerenter',()=>{if(!statsDismissed)statsHeader.classList.add('stats-open');syncStatsToggle();});
  const leaveStatsHover=e=>{if(statsToggle.contains(e.relatedTarget)||$('perf-overview').contains(e.relatedTarget)||$('stats-close').contains(e.relatedTarget))return;statsHeader.classList.remove('stats-open');syncStatsToggle();};
  statsToggle.addEventListener('pointerleave',leaveStatsHover);
  $('perf-overview').addEventListener('pointerleave',leaveStatsHover);
  statsHeader.addEventListener('pointerleave',()=>{statsDismissed=false;statsHeader.classList.remove('stats-open');syncStatsToggle();});
  statsHeader.addEventListener('focusout',e=>{if(!statsHeader.contains(e.relatedTarget))statsDismissed=false;});
  setTimeout(()=>{statsHeader.classList.remove('stats-initial');syncStatsToggle();},5000);
  syncStatsToggle();
  const syncStatsHeight = () => { const h=document.querySelector('.trace-pair>.sec:first-child').getBoundingClientRect().height; $("run-header").style.setProperty('--stats-height',h+'px'); };
  new ResizeObserver(syncStatsHeight).observe(document.querySelector('.trace-pair>.sec:first-child'));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeStats();});
  document.addEventListener("click",e=>{document.querySelectorAll('.bar-menu[open]').forEach(d=>{if(!d.contains(e.target))d.open=false;});},true);
  document.addEventListener("keydown",e=>{if(e.key==='Escape')document.querySelectorAll('.bar-menu[open]').forEach(d=>d.open=false);});
  $("lane-zoom").addEventListener('pointerenter',()=>{drawLaneRelations();$("lane-hover-tip").hidden=true;hideUiTip();});
  $("lane-zoom").addEventListener("click", (e) => {
    if (e.target.closest("[data-rows]")) {
      const wrap = $("lane-wrap"), scroll = wrap.scrollTop;
      const anchor = laneRowCenters.reduce((best, y, index) =>
        Math.abs(y - scroll) < Math.abs(laneRowCenters[best] - scroll) ? index : best, 0);
      const offset = (laneRowCenters[anchor] || 0) - scroll;
      laneExpanded = !laneExpanded;
      renderLane();
      wrap.scrollTop = scroll > 0 ? Math.max(0, (laneRowCenters[anchor] || 0) - offset) : 0;
      $("lane-rows").focus({ preventScroll: true });
      return;
    }

    if (e.target.closest("[data-zoom]")) { const full = R.kpi.windowUs, range = laneRange || [0,full], span = Math.min(full, Math.max(full/256, (range[1]-range[0]) * (e.target.closest("[data-zoom]").dataset.zoom === "in" ? .5 : 2))), start = Math.max(0, Math.min(full-span, (range[0]+range[1]-span)/2)); laneRange = span === full ? null : [start,start+span]; renderLane(); return; }
    if (e.target.closest("[data-zoom-reset]")) { laneRange = null; renderLane(); return; }
  });
  $("lane-ovl").addEventListener('change',e=>{if(e.target.id==='lane-view-selector'){laneView=e.target.value;renderLane();}});
  document.addEventListener("click", (e) => {
    if(!e.target.closest('#lane-ovl,#lane-zoom'))return;
    const color = e.target.closest("[data-color]");
    const feature = e.target.closest("[data-task-layer]");
    if (color || feature) {
      if (color) laneColor = color.dataset.color;
      else { taskLayer = feature.dataset.taskLayer; candidateFilter = taskLayer === "none" ? "recommended" : taskLayer; recommendedFocus = null; laneComposition = false; }
      const selector = color ? `[data-color="${laneColor}"]` : `[data-task-layer="${taskLayer}"]`;
      renderLane(); document.querySelector(selector)?.focus({preventScroll:true}); return;
    }
    const v = e.target.closest("[data-view]");
    if (v) { laneView = v.dataset.view; renderLane();$("lane-ovl").querySelector('[data-menu="view"]').open=false; return; }
    const b = e.target.closest("[data-ovl]"); if (!b) return;
    const k = b.dataset.ovl;
    if (k === "path") pathVisible = !pathVisible;
    else if (k === "only") laneAll = !laneAll;
    else if (k === "composition") laneComposition = !laneComposition;
    else ovl[k] = !ovl[k];
    renderLane();
  });
  $("drawer-close").addEventListener("click", clearSelection);
  $("composition-toggle").onclick = () => { laneComposition = !laneComposition; renderLane(); $("composition-toggle").setAttribute("aria-pressed", String(laneComposition)); };
  $("evidence-open").onclick = () => { renderEvidence(); $("evidence-dialog").showModal(); };
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("pass-dialog").open && !$("evidence-dialog").open) clearSelection(); });
  $("lane-wrap").addEventListener("wheel", (e) => {
    if (!e.ctrlKey && !e.metaKey && !e.shiftKey) return;
    e.preventDefault();
    const full = R.kpi.windowUs, current = laneRange || [0, full];
    const currentSpan = current[1] - current[0];
    if (e.shiftKey && !e.ctrlKey && !e.metaKey) {
      const start = Math.max(0, Math.min(full - currentSpan, current[0] + Math.sign(e.deltaY) * currentSpan * .2));
      laneRange = start === 0 && currentSpan === full ? null : [start, start + currentSpan];
      if (!laneZoomRaf) laneZoomRaf = requestAnimationFrame(() => { laneZoomRaf = 0; renderLane(); });
      return;
    }
    const factor = Math.exp(Math.max(-2, Math.min(2, e.deltaY * .005)));
    const minSpan = Math.max(1, full / 256), nextSpan = Math.min(full, Math.max(minSpan, currentSpan * factor));
    const svg = $("lane"), rect = svg.getBoundingClientRect(), W = svg.viewBox.baseVal.width;
    if (!rect.width || nextSpan === currentSpan) return;
    const x = (e.clientX - rect.left) / rect.width * W;
    const LEFT = laneLeft(), RIGHT = 12;
    const anchorRatio = Math.max(0, Math.min(1, (x - LEFT) / (W - LEFT - RIGHT)));
    const anchor = current[0] + currentSpan * anchorRatio;
    let start = anchor - nextSpan * anchorRatio;
    start = Math.max(0, Math.min(full - nextSpan, start));
    laneRange = nextSpan >= full - 1e-6 ? null : [start, start + nextSpan];
    if (!laneZoomRaf) laneZoomRaf = requestAnimationFrame(() => { laneZoomRaf = 0; renderLane(); });
  }, { passive: false });
  const laneWrap = $("lane-wrap");
  laneWrap.tabIndex=0;

  laneWrap.addEventListener('dblclick',e=>{
    const rect=$("lane").getBoundingClientRect(),ratio=Math.max(0,Math.min(1,(e.clientX-rect.left-laneLeft())/(rect.width-laneLeft()-12)));
    const range=laneRange||[0,R.kpi.windowUs],span=(range[1]-range[0])*.5,anchor=range[0]+(range[1]-range[0])*ratio;
    setLaneRange(anchor-span*ratio,anchor+span*(1-ratio));
  });
  laneWrap.addEventListener('keydown',e=>{
    if(e.target!==laneWrap)return;
    const range=laneRange||[0,R.kpi.windowUs],span=range[1]-range[0];
    if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();const d=span*.1*(e.key==='ArrowRight'?1:-1);setLaneRange(range[0]+d,range[1]+d);}
    else if(['+','=','-'].includes(e.key)){e.preventDefault();const next=span*(e.key==='-'?1.25:.8),center=(range[0]+range[1])/2;setLaneRange(center-next/2,center+next/2);}
  });
  let laneDrag = null, suppressLaneClick = false;
  laneWrap.addEventListener("pointerdown", (e) => {
    if (!laneRange || e.button !== 0 || e.pointerType !== "mouse") return;
    const svg = $("lane"), rect = svg.getBoundingClientRect(), W = svg.viewBox.baseVal.width;
    const LEFT = laneLeft(), RIGHT = 12;
    const timelinePx = rect.width * (W - LEFT - RIGHT) / W;
    if (!timelinePx) return;
    laneDrag = { pointerId: e.pointerId, x: e.clientX, start: laneRange[0], span: laneRange[1] - laneRange[0], timelinePx, moved: false };
  });
  window.addEventListener("pointermove", (e) => {
    if (!laneDrag || e.pointerId !== laneDrag.pointerId) return;
    const dx = e.clientX - laneDrag.x;
    if (!laneDrag.moved && Math.abs(dx) < 4) return;
    laneDrag.moved = true;
    laneWrap.classList.add("is-dragging");
    e.preventDefault();
    const full = R.kpi.windowUs;
    const start = Math.max(0, Math.min(full - laneDrag.span, laneDrag.start - dx * laneDrag.span / laneDrag.timelinePx));
    laneRange = [start, start + laneDrag.span];
    if (!laneZoomRaf) laneZoomRaf = requestAnimationFrame(() => { laneZoomRaf = 0; renderLane(); });
  });
  const endLaneDrag = (e) => {
    if (!laneDrag || e.pointerId !== laneDrag.pointerId) return;
    const moved = laneDrag.moved;
    laneDrag = null;
    laneWrap.classList.remove("is-dragging");
    if (moved) {
      suppressLaneClick = true;
      setTimeout(() => { suppressLaneClick = false; }, 0);
    }
  };
  window.addEventListener("pointerup", endLaneDrag);
  window.addEventListener("pointercancel", endLaneDrag);
  laneWrap.addEventListener("click", (e) => {
    if (!suppressLaneClick) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);
  let laneResizeRaf = 0;
  window.addEventListener("resize", () => {
    if (laneResizeRaf) cancelAnimationFrame(laneResizeRaf);
    laneResizeRaf = requestAnimationFrame(() => { laneResizeRaf = 0; if(singlePanelOpen)updateSingleGrip(); criticalPath(); renderLane(); });
  });
  window.CompileLaneAdapter={
    enterSplit:()=>{ovl.ribbon=false;pathAnalysisActive=false;taskLayer="none";recommendedFocus=null;$("analysis-panel-anchor").classList.remove("results-open");},
    leaveCompile:()=>{document.body.classList.remove('compile-analysis-mode');},
    resize:()=>{renderLane();window.dispatchEvent(new Event('compile-lane-resized'));},
    current:()=>({rank:R.rank,selected:R.launches.find(l=>l.id===me),launches:R.launches}),
    select:id=>{select(id);setDrawer(false);},
    preview:(kernels,taskId,finding)=>{
      $("lane").querySelector('#compile-event-preview')?.remove();
      $("lane").querySelector('#compile-finding-tag')?.remove();
      if(!kernels?.length||!laneRelationIndex)return;
      const paths=[];
      for(const entry of laneRelationIndex.byElement.values())if(kernels.includes(entry.task.leaf)&&(!taskId||entry.task.taskId===taskId)){
        const b=entry.box;paths.push(`M${b.x} ${b.cy}h${Math.max(1,b.w)}`);
      }
      $("lane").append(el('path',{id:'compile-event-preview',d:paths.join(' '),fill:'none',stroke:'#fff','stroke-width':3,'pointer-events':'none'}));
      if(finding&&paths.length){
        const entries=[...laneRelationIndex.byElement.values()].filter(entry=>kernels.includes(entry.task.leaf));
        const x=Math.max(laneLeft(),Math.min(...entries.map(e=>e.box.x))),y=Math.max(16,Math.min(...entries.map(e=>e.box.cy))-18);
        const g=el('g',{id:'compile-finding-tag','pointer-events':'none'}),w=Math.min(280,finding.title.length*14+28);
        g.append(el('rect',{x,y:y-14,width:w,height:28,rx:14,fill:finding.color}));
        const t=el('text',{x:x+14,y:y+5,fill:'#111','font-size':13,'font-family':'var(--font)'});t.textContent=finding.title;g.append(t);$("lane").append(g);
      }
    }
  };
  const originalPathSection=document.querySelector('.trace-pair>.sec:first-child');
  const pathLane=document.createElement('div');pathLane.id='path-analysis-lane';pathLane.setAttribute('aria-label','关键路径依赖顺序泳道');
  while(originalPathSection.firstChild)pathLane.append(originalPathSection.firstChild);
  document.querySelector('.lane-axis-sticky').prepend(pathLane);
  window.CriticalPathIntegration.mount({
    state: () => ({ rank: R, selected: me, range: laneRange, left: laneLeft() }),
    range: (a,b) => setLaneRange(a,b),
    select: id => {
      const task=R.launches.find(t=>String(t.taskId)===String(id));if(!task)return;
      qkInline=null;qkReturnView=null;me=task.id;paint();setDrawer(false);
    },
    hover: id => drawLaneRelations((laneRelationIndex?.byTask.get(String(id)) || [])[0]?.element),
    redraw: () => renderLane()
  });
  loadRank(D.ranks[0].rank);
}
})();
