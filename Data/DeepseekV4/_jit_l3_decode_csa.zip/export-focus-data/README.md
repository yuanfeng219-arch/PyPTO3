# index-focus.html 渲染数据导出

导出日期：2026-11-05。对应页面：`Design/device-perf-lane/index-focus.html`。本目录是数据快照和规则参考，不是独立运行的网页。

## 目录与口径

- `raw/rank*/d0/`：构建泳道数据所用的归档源文件原样副本，包括 `merged_swimlane_*.json`、`deps.json`、`name_map.json`、`chip_swimlane_records.json`。来自 `Data/DeepseekV4/_jit_l3_decode_csa_20260903_010617/dfx_outputs/`。merged swimlane 含影子事件；生成泳道数据时只保留有 `kernel-duration-us` 的事件，详见原目录 `README.md` 和 `scripts/build_perf_lane.mjs`。
- `derived/lane-data-inline.json`：从目标页面 `lane-data` 标签逐值提取的完整输入，包含两个 rank 的 launches、blocks、cores、edges、criticalPath 和 KPI。这是处理过的 trace 和编译信息，不是原始采集文件。
- `derived/parallel-lane.json`：泳道构建时关联的编译信息；`derived/pass-analysis.json` 是页面加载的 Pass 分析数据；`derived/compile/` 是编译联动使用的图、Pass、指令等 JSON。它们包含从归档产物整理的内容及人工整理的结构，不应一概视为实测。
- `mock/lane-data-rendered.json`：页面对上述内联数据应用 `QK_RESIDENCY.withLongBlock` 后的数据快照。该函数人为延长每个 rank 的一个 QK block（原 compute 的 80%），移动部分后续时间并重新计算部分统计；它是用于演示的混合数据，不能用于真实性能结论。
- `mock/qk-inline-events.json`：对上述混合快照中每个 QK AIC/AIV block 调用页面的 `inlineEvents` 得到的核内示意事件，按 rank、task、leaf、core 分组。事件时间和重叠是合成的，并非指令级 trace；AIC 条目也可能包含关联的 AIV 示意事件。
- `mock/qk-pipeline-models.json`：`QK_PIPELINE_PASSES.model(kind, 0)` 四种示意布局，迭代从 0 开始，时间为相对示意量，并非实测。其他迭代可用 `source/qk-pipeline-passes.js` 中的生成函数重建。
- `source/`：页面内联逻辑、数据与模拟生成脚本、编译联动源码节选；含无法直接序列化为单一 JSON 的布局、硬编码场景、阈值、计算规则和交互衍生数据。例如 `pass-objects.js` 保存结构场景，`compile-linked/main.jsx` 包含人工构造的分析场景。文件为参考副本，依赖关系未重新打包，不保证可在本目录单独执行。

## 使用提示

主泳道可先读取 `mock/lane-data-rendered.json` 重现页面初始渲染数据；需要原始派生口径时读取 `derived/lane-data-inline.json`，并参考源文件计算视图。时间字段一般以 `Us` 表示微秒，`taskId` 是字符串；同一个 taskId 可对应 AIC/AIV 不同 launch，以 `id` 或 `taskId + leaf` 区分。筛选、图形布局、选中状态和部分文案由 `source/` 中的代码运行时生成；编译联动还有由静态图和 Pass 增量计算的状态，不能只靠一个 JSON 恢复全部交互。

原始归档来源与转换规则以仓库内 `Design/device-perf-lane/README.md`、`scripts/build_perf_lane.mjs` 及各源文件为准；页面中的模拟与静态示意不代表 NPU 实测。
